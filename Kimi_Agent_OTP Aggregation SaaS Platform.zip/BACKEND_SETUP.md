# OTP Hub - Backend API Setup Guide

## Quick Start (Node.js + Express)

### 1. Project Setup
```bash
mkdir otp-hub-backend
cd otp-hub-backend
npm init -y
npm install express cors helmet bcryptjs jsonwebtoken pg prisma @prisma/client dotenv
npm install -D typescript ts-node @types/express @types/node @types/bcryptjs @types/jsonwebtoken nodemon
```

### 2. Folder Structure
```
otp-hub-backend/
├── src/
│   ├── config/
│   │   ├── database.ts
│   │   └── stripe.ts
│   ├── controllers/
│   │   ├── auth.controller.ts
│   │   ├── otp.controller.ts
│   │   ├── phone.controller.ts
│   │   ├── subscription.controller.ts
│   │   └── ticket.controller.ts
│   ├── middleware/
│   │   ├── auth.middleware.ts
│   │   └── rateLimit.middleware.ts
│   ├── routes/
│   │   ├── auth.routes.ts
│   │   ├── otp.routes.ts
│   │   ├── phone.routes.ts
│   │   ├── subscription.routes.ts
│   │   └── ticket.routes.ts
│   ├── services/
│   │   ├── twilio.service.ts
│   │   ├── stripe.service.ts
│   │   └── fcm.service.ts
│   ├── utils/
│   │   └── encryption.ts
│   └── app.ts
├── prisma/
│   └── schema.prisma
├── .env
├── package.json
└── tsconfig.json
```

### 3. Environment Variables (.env)
```env
# Server
PORT=5000
NODE_ENV=development

# Database
DATABASE_URL="postgresql://user:password@localhost:5432/otphub?schema=public"

# JWT
JWT_SECRET="your-super-secret-jwt-key-change-this-in-production"
JWT_EXPIRES_IN="7d"

# Twilio (for SMS)
TWILIO_ACCOUNT_SID="your-twilio-account-sid"
TWILIO_AUTH_TOKEN="your-twilio-auth-token"
TWILIO_PHONE_NUMBER="your-twilio-phone-number"

# Stripe (for payments)
STRIPE_SECRET_KEY="sk_test_your-stripe-secret-key"
STRIPE_WEBHOOK_SECRET="whsec_your-webhook-secret"
STRIPE_PRICE_BASIC_MONTHLY="price_basic_monthly_id"
STRIPE_PRICE_BASIC_YEARLY="price_basic_yearly_id"
STRIPE_PRICE_PRO_MONTHLY="price_pro_monthly_id"
STRIPE_PRICE_PRO_YEARLY="price_pro_yearly_id"

# Firebase (for push notifications)
FIREBASE_SERVICE_ACCOUNT='{"type":"service_account",...}'

# Encryption
ENCRYPTION_KEY="your-32-char-encryption-key-here!!"
```

### 4. Database Schema (prisma/schema.prisma)
```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id                  String    @id @default(uuid())
  email               String    @unique
  passwordHash        String
  name                String
  role                Role      @default(USER)
  subscriptionTier    Tier      @default(FREE)
  subscriptionStatus  String    @default("active")
  subscriptionExpires DateTime?
  emailVerified       Boolean   @default(false)
  createdAt           DateTime  @default(now())
  updatedAt           DateTime  @updatedAt

  phoneNumbers PhoneNumber[]
  otpMessages  OTPMessage[]
  tickets      SupportTicket[]
  payments     Payment[]
  subscription Subscription?

  @@map("users")
}

model PhoneNumber {
  id          String   @id @default(uuid())
  userId      String
  number      String
  label       String?
  countryCode String?
  isActive    Boolean  @default(true)
  isVerified  Boolean  @default(false)
  deviceType  String?
  twilioSid   String?
  createdAt   DateTime @default(now())

  user        User         @relation(fields: [userId], references: [id], onDelete: Cascade)
  otpMessages OTPMessage[]

  @@map("phone_numbers")
}

model OTPMessage {
  id            String   @id @default(uuid())
  userId        String
  phoneNumberId String
  sender        String
  code          String
  message       String
  isRead        Boolean  @default(false)
  receivedAt    DateTime @default(now())
  expiresAt     DateTime?

  user        User        @relation(fields: [userId], references: [id], onDelete: Cascade)
  phoneNumber PhoneNumber @relation(fields: [phoneNumberId], references: [id], onDelete: Cascade)

  @@map("otp_messages")
}

model Subscription {
  id                String   @id @default(uuid())
  userId            String   @unique
  stripeId          String?
  planId            String
  status            String
  billingCycle      String
  currentPeriodStart DateTime
  currentPeriodEnd   DateTime
  createdAt         DateTime @default(now())

  user     User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  payments Payment[]

  @@map("subscriptions")
}

model Payment {
  id              String   @id @default(uuid())
  userId          String
  subscriptionId  String?
  amount          Decimal
  currency        String   @default("USD")
  status          String
  paymentMethod   String
  stripePaymentId String?
  createdAt       DateTime @default(now())

  user         User          @relation(fields: [userId], references: [id], onDelete: Cascade)
  subscription Subscription? @relation(fields: [subscriptionId], references: [id])

  @@map("payments")
}

model SupportTicket {
  id          String   @id @default(uuid())
  userId      String
  subject     String
  description String
  category    String
  priority    String   @default("medium")
  status      String   @default("open")
  assignedTo  String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  user      User              @relation(fields: [userId], references: [id], onDelete: Cascade)
  responses TicketResponse[]

  @@map("support_tickets")
}

model TicketResponse {
  id        String   @id @default(uuid())
  ticketId  String
  userId    String
  message   String
  createdAt DateTime @default(now())

  ticket SupportTicket @relation(fields: [ticketId], references: [id], onDelete: Cascade)

  @@map("ticket_responses")
}

enum Role {
  USER
  ADMIN
  SUPERADMIN
}

enum Tier {
  FREE
  BASIC
  PRO
  ENTERPRISE
}
```

### 5. Main App (src/app.ts)
```typescript
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';

import authRoutes from './routes/auth.routes';
import otpRoutes from './routes/otp.routes';
import phoneRoutes from './routes/phone.routes';
import subscriptionRoutes from './routes/subscription.routes';
import ticketRoutes from './routes/ticket.routes';

dotenv.config();

const app = express();

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));
app.use(express.json());
app.use(express.raw({ type: 'application/json' })); // For Stripe webhooks

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/otp', otpRoutes);
app.use('/api/phones', phoneRoutes);
app.use('/api/subscriptions', subscriptionRoutes);
app.use('/api/tickets', ticketRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handler
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

### 6. Authentication Controller (src/controllers/auth.controller.ts)
```typescript
import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const register = async (req: Request, res: Response) => {
  try {
    const { email, password, name } = req.body;

    // Check if user exists
    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);

    // Create user
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        name,
        subscriptionTier: 'FREE'
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        subscriptionTier: true,
        createdAt: true
      }
    });

    // Generate JWT
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET!,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    res.status(201).json({ user, token });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
};

export const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Verify password
    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate JWT
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET!,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    res.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        subscriptionTier: user.subscriptionTier,
        subscriptionExpires: user.subscriptionExpires
      },
      token
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
};

export const getMe = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.userId;
    
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        subscriptionTier: true,
        subscriptionExpires: true,
        createdAt: true
      }
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: 'Failed to get user' });
  }
};
```

### 7. Auth Middleware (src/middleware/auth.middleware.ts)
```typescript
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export const authenticate = (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET!);
    (req as any).user = decoded;
    
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

export const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
  const user = (req as any).user;
  
  if (user.role !== 'ADMIN' && user.role !== 'SUPERADMIN') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  next();
};
```

### 8. Twilio SMS Service (src/services/twilio.service.ts)
```typescript
import twilio from 'twilio';

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

export const purchaseNumber = async (areaCode: string) => {
  try {
    const number = await client.availablePhoneNumbers('US')
      .local
      .list({ areaCode, limit: 1 });

    if (number.length === 0) {
      throw new Error('No numbers available');
    }

    const purchased = await client.incomingPhoneNumbers.create({
      phoneNumber: number[0].phoneNumber,
      smsUrl: `${process.env.API_URL}/webhooks/twilio/sms`
    });

    return purchased;
  } catch (error) {
    console.error('Purchase number error:', error);
    throw error;
  }
};

export const extractOTP = (message: string): string | null => {
  // Common OTP patterns
  const patterns = [
    /\b\d{4,8}\b/,           // 4-8 digit codes
    /code[\s:]*(\d+)/i,      // "code: 123456"
    /otp[\s:]*(\d+)/i,       // "OTP: 123456"
    /verification[\s:]*(\d+)/i,
    /(\d{6})/                // 6-digit codes
  ];

  for (const pattern of patterns) {
    const match = message.match(pattern);
    if (match) {
      return match[1] || match[0];
    }
  }

  return null;
};
```

### 9. Webhook Handler for Incoming SMS
```typescript
// src/controllers/webhook.controller.ts
import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { extractOTP } from '../services/twilio.service';

const prisma = new PrismaClient();

export const handleIncomingSMS = async (req: Request, res: Response) => {
  try {
    const { From, Body, To } = req.body;

    // Find the phone number in our database
    const phoneNumber = await prisma.phoneNumber.findFirst({
      where: { number: To },
      include: { user: true }
    });

    if (!phoneNumber) {
      return res.status(404).json({ error: 'Number not found' });
    }

    // Extract OTP
    const code = extractOTP(Body);

    // Save OTP message
    const otpMessage = await prisma.oTPMessage.create({
      data: {
        userId: phoneNumber.userId,
        phoneNumberId: phoneNumber.id,
        sender: From,
        code: code || 'N/A',
        message: Body,
        expiresAt: new Date(Date.now() + 10 * 60 * 1000) // 10 minutes
      }
    });

    // Send push notification via FCM
    await sendPushNotification(phoneNumber.userId, {
      title: `New OTP from ${From}`,
      body: code ? `Code: ${code}` : 'New message received',
      data: { messageId: otpMessage.id }
    });

    res.status(200).send('OK');
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({ error: 'Failed to process SMS' });
  }
};
```

### 10. Deployment Script
```bash
#!/bin/bash
# deploy.sh

# Build TypeScript
npm run build

# Run migrations
npx prisma migrate deploy

# Start server
pm2 start dist/app.js --name "otp-hub-api"
pm2 save
```

---

## 🚀 Deployment Options

### Option 1: Railway (Easiest)
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway init
railway up
```

### Option 2: Render
1. Connect GitHub repo
2. Set environment variables
3. Deploy automatically

### Option 3: AWS (Most Control)
- EC2 for server
- RDS for PostgreSQL
- Elastic Beanstalk for easy deployment

---

## 📊 Database Migration Commands

```bash
# Initialize Prisma
npx prisma init

# Create migration
npx prisma migrate dev --name init

# Deploy migration
npx prisma migrate deploy

# Generate client
npx prisma generate

# Open Prisma Studio (GUI)
npx prisma studio
```

---

**Next: Build the Android app to receive SMS from physical phones!** 📱
