# OTP Hub - Android App Development Guide

## 📱 Complete Android App Setup

### 1. Project Setup

#### Create New Project in Android Studio
```
Name: OTP Hub
Package: com.otphub.app
Language: Kotlin
Minimum SDK: API 24 (Android 7.0)
```

#### Required Dependencies (build.gradle)
```gradle
plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
    id 'com.google.gms.google-services' // Firebase
}

android {
    namespace 'com.otphub.app'
    compileSdk 34

    defaultConfig {
        applicationId "com.otphub.app"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    buildFeatures {
        compose true
    }

    composeOptions {
        kotlinCompilerExtensionVersion '1.5.0'
    }

    kotlinOptions {
        jvmTarget = '1.8'
    }
}

dependencies {
    // Core
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.6.2'
    implementation 'androidx.activity:activity-compose:1.8.0'

    // Compose
    implementation platform('androidx.compose:compose-bom:2023.10.00')
    implementation 'androidx.compose.ui:ui'
    implementation 'androidx.compose.ui:ui-graphics'
    implementation 'androidx.compose.ui:ui-tooling-preview'
    implementation 'androidx.compose.material3:material3'

    // Navigation
    implementation 'androidx.navigation:navigation-compose:2.7.4'

    // ViewModel
    implementation 'androidx.lifecycle:lifecycle-viewmodel-compose:2.6.2'

    // Retrofit (API calls)
    implementation 'com.squareup.retrofit2:retrofit:2.9.0'
    implementation 'com.squareup.retrofit2:converter-gson:2.9.0'
    implementation 'com.squareup.okhttp3:logging-interceptor:4.11.0'

    // Firebase
    implementation platform('com.google.firebase:firebase-bom:32.4.0')
    implementation 'com.google.firebase:firebase-messaging-ktx'
    implementation 'com.google.firebase:firebase-analytics-ktx'

    // DataStore (local storage)
    implementation 'androidx.datastore:datastore-preferences:1.0.0'

    // Coroutines
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3'

    // Billing (Google Play)
    implementation 'com.android.billingclient:billing-ktx:6.1.0'

    // Room (local database)
    implementation 'androidx.room:room-runtime:2.6.0'
    implementation 'androidx.room:room-ktx:2.6.0'
    kapt 'androidx.room:room-compiler:2.6.0'

    // Testing
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}
```

### 2. Android Manifest
```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Internet -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- SMS -->
    <uses-permission android:name="android.permission.RECEIVE_SMS" />
    <uses-permission android:name="android.permission.READ_SMS" />
    <uses-permission android:name="android.permission.SEND_SMS" />

    <!-- Foreground Service -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <!-- Boot -->
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

    <application
        android:name=".OTPHubApplication"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.OTPHub"
        tools:targetApi="31">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.OTPHub">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- SMS Receiver -->
        <receiver
            android:name=".receiver.SMSReceiver"
            android:exported="true"
            android:permission="android.permission.BROADCAST_SMS">
            <intent-filter>
                <action android:name="android.provider.Telephony.SMS_RECEIVED" />
            </intent-filter>
        </receiver>

        <!-- Boot Receiver -->
        <receiver
            android:name=".receiver.BootReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>

        <!-- Foreground Service -->
        <service
            android:name=".service.SMSService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="dataSync" />

        <!-- Firebase Messaging Service -->
        <service
            android:name=".service.OTPHubFirebaseService"
            android:exported="false">
            <intent-filter>
                <action android:name="com.google.firebase.MESSAGING_EVENT" />
            </intent-filter>
        </service>

    </application>
</manifest>
```

### 3. Core Components

#### SMS Receiver (receiver/SMSReceiver.kt)
```kotlin
package com.otphub.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.otphub.app.service.SMSService
import com.otphub.app.data.api.RetrofitClient
import com.otphub.app.data.model.OTPMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SMSReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            
            messages?.forEach { message ->
                val sender = message.originatingAddress ?: return@forEach
                val body = message.messageBody ?: return@forEach
                
                Log.d("SMSReceiver", "SMS from $sender: $body")
                
                // Extract OTP
                val otp = extractOTP(body)
                
                // Send to server
                sendToServer(context, sender, body, otp)
                
                // Show notification
                showNotification(context, sender, otp)
            }
        }
    }

    private fun extractOTP(message: String): String? {
        val patterns = listOf(
            Regex("\\b\\d{6}\\b"),  // 6-digit codes
            Regex("(?i)code\\s*:?\\s*(\\d+)"),
            Regex("(?i)otp\\s*:?\\s*(\\d+)"),
            Regex("(?i)verification\\s*:?\\s*(\\d+)")
        )
        
        patterns.forEach { pattern ->
            pattern.find(message)?.let { return it.value }
        }
        
        return null
    }

    private fun sendToServer(context: Context, sender: String, body: String, otp: String?) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = context.getSharedPreferences("auth", Context.MODE_PRIVATE)
                val token = prefs.getString("token", null) ?: return@launch
                
                val message = OTPMessage(
                    sender = sender,
                    message = body,
                    code = otp ?: "N/A"
                )
                
                RetrofitClient.apiService.sendOTP("Bearer $token", message)
            } catch (e: Exception) {
                Log.e("SMSReceiver", "Failed to send OTP", e)
            }
        }
    }

    private fun showNotification(context: Context, sender: String, otp: String?) {
        // Show local notification
        NotificationHelper.showOTPNotification(context, sender, otp)
    }
}
```

#### Foreground Service (service/SMSService.kt)
```kotlin
package com.otphub.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.otphub.app.MainActivity
import com.otphub.app.R

class SMSService : Service() {

    companion object {
        const val CHANNEL_ID = "OTP_HUB_SERVICE"
        const val NOTIFICATION_ID = 1
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification()
        startForeground(NOTIFICATION_ID, notification)
        
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "OTP Hub Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps OTP Hub running to forward SMS"
        }

        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OTP Hub is active")
            .setContentText("Forwarding SMS to your dashboard")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }
}
```

#### API Service (data/api/ApiService.kt)
```kotlin
package com.otphub.app.data.api

import com.otphub.app.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // Auth
    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<AuthResponse>

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<AuthResponse>

    @GET("api/auth/me")
    suspend fun getMe(@Header("Authorization") token: String): Response<UserResponse>

    // OTP Messages
    @POST("api/otp/receive")
    suspend fun sendOTP(
        @Header("Authorization") token: String,
        @Body message: OTPMessage
    ): Response<Unit>

    @GET("api/otp")
    suspend fun getOTPs(
        @Header("Authorization") token: String
    ): Response<List<OTPMessageResponse>>

    // Phone Numbers
    @GET("api/phones")
    suspend fun getPhoneNumbers(
        @Header("Authorization") token: String
    ): Response<List<PhoneNumberResponse>>

    @POST("api/phones")
    suspend fun addPhoneNumber(
        @Header("Authorization") token: String,
        @Body request: AddPhoneRequest
    ): Response<PhoneNumberResponse>

    // Subscriptions
    @GET("api/subscriptions/plans")
    suspend fun getPlans(): Response<List<SubscriptionPlan>>

    @POST("api/subscriptions/create-checkout")
    suspend fun createCheckoutSession(
        @Header("Authorization") token: String,
        @Body request: CheckoutRequest
    ): Response<CheckoutResponse>

    // Tickets
    @GET("api/tickets")
    suspend fun getTickets(
        @Header("Authorization") token: String
    ): Response<List<SupportTicket>>

    @POST("api/tickets")
    suspend fun createTicket(
        @Header("Authorization") token: String,
        @Body request: CreateTicketRequest
    ): Response<SupportTicket>
}
```

#### Retrofit Client (data/api/RetrofitClient.kt)
```kotlin
package com.otphub.app.data.api

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {

    private const val BASE_URL = "https://your-api-domain.com/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .build()

    val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val apiService: ApiService = retrofit.create(ApiService::class.java)
}
```

### 4. UI Components (Compose)

#### Main Activity (MainActivity.kt)
```kotlin
package com.otphub.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.otphub.app.navigation.OTPNavHost
import com.otphub.app.service.SMSService
import com.otphub.app.ui.theme.OTPTheme

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        when {
            permissions[Manifest.permission.RECEIVE_SMS] == true -> {
                // Permission granted, start service
                startSMSService()
            }
            else -> {
                // Permission denied
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        checkPermissions()

        setContent {
            OTPTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    OTPNavHost()
                }
            }
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECEIVE_SMS)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissions.isNotEmpty()) {
            requestPermissionLauncher.launch(permissions.toTypedArray())
        } else {
            startSMSService()
        }
    }

    private fun startSMSService() {
        val intent = Intent(this, SMSService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }
}
```

#### Navigation (navigation/OTPNavHost.kt)
```kotlin
package com.otphub.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.otphub.app.ui.screens.*

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")
    object Dashboard : Screen("dashboard")
    object OTPInbox : Screen("otp_inbox")
    object PhoneNumbers : Screen("phone_numbers")
    object Subscription : Screen("subscription")
    object Tickets : Screen("tickets")
    object Settings : Screen("settings")
}

@Composable
fun OTPNavHost(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route
    ) {
        composable(Screen.Login.route) {
            LoginScreen(
                onNavigateToRegister = { navController.navigate(Screen.Register.route) },
                onLoginSuccess = {
                    navController.navigate(Screen.Dashboard.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                onNavigateToLogin = { navController.navigateUp() },
                onRegisterSuccess = {
                    navController.navigate(Screen.Dashboard.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Dashboard.route) {
            DashboardScreen(
                onNavigateToOTPInbox = { navController.navigate(Screen.OTPInbox.route) },
                onNavigateToPhones = { navController.navigate(Screen.PhoneNumbers.route) },
                onNavigateToSubscription = { navController.navigate(Screen.Subscription.route) },
                onNavigateToTickets = { navController.navigate(Screen.Tickets.route) },
                onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
            )
        }

        composable(Screen.OTPInbox.route) {
            OTPInboxScreen(onNavigateBack = { navController.navigateUp() })
        }

        composable(Screen.PhoneNumbers.route) {
            PhoneNumbersScreen(onNavigateBack = { navController.navigateUp() })
        }

        composable(Screen.Subscription.route) {
            SubscriptionScreen(onNavigateBack = { navController.navigateUp() })
        }

        composable(Screen.Tickets.route) {
            TicketsScreen(onNavigateBack = { navController.navigateUp() })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = { navController.navigateUp() },
                onLogout = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
    }
}
```

### 5. Google Play Billing Integration

#### Billing Manager (billing/BillingManager.kt)
```kotlin
package com.otphub.app.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class BillingManager(private val context: Context) {

    private val _purchases = MutableStateFlow<List<Purchase>>(emptyList())
    val purchases: StateFlow<List<Purchase>> = _purchases

    private val billingClient = BillingClient.newBuilder(context)
        .setListener(purchasesUpdatedListener)
        .enablePendingPurchases()
        .build()

    private val purchasesUpdatedListener = PurchasesUpdatedListener { billingResult, purchases ->
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
            purchases?.let { _purchases.value = it }
        }
    }

    fun startConnection(onConnected: () -> Unit) {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    onConnected()
                }
            }

            override fun onBillingServiceDisconnected() {
                // Retry connection
            }
        })
    }

    suspend fun queryProductDetails(productIds: List<String>): List<ProductDetails> {
        val productList = productIds.map { productId ->
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        }

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        val result = billingClient.queryProductDetails(params)
        return result.productDetailsList ?: emptyList()
    }

    fun launchBillingFlow(activity: Activity, productDetails: ProductDetails) {
        val offerToken = productDetails.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: return

        val productDetailsParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(productDetails)
            .setOfferToken(offerToken)
            .build()

        val billingFlowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productDetailsParams))
            .build()

        billingClient.launchBillingFlow(activity, billingFlowParams)
    }

    companion object {
        const val BASIC_MONTHLY = "basic_monthly"
        const val BASIC_YEARLY = "basic_yearly"
        const val PRO_MONTHLY = "pro_monthly"
        const val PRO_YEARLY = "pro_yearly"
        const val ENTERPRISE_MONTHLY = "enterprise_monthly"
        const val ENTERPRISE_YEARLY = "enterprise_yearly"
    }
}
```

### 6. Firebase Setup

#### Firebase Service (service/OTPHubFirebaseService.kt)
```kotlin
package com.otphub.app.service

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.otphub.app.data.api.RetrofitClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class OTPHubFirebaseService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM", "New token: $token")
        
        // Send token to server
        sendTokenToServer(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        
        val title = message.notification?.title ?: "OTP Hub"
        val body = message.notification?.body ?: "New message"
        
        // Show notification
        NotificationHelper.showNotification(this, title, body)
    }

    private fun sendTokenToServer(token: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Call API to update FCM token
                // RetrofitClient.apiService.updateFCMToken(token)
            } catch (e: Exception) {
                Log.e("FCM", "Failed to send token", e)
            }
        }
    }
}
```

### 7. Build & Release

#### Build Release APK
```bash
# Generate signed APK
./gradlew assembleRelease

# Or App Bundle (recommended for Play Store)
./gradlew bundleRelease
```

#### Signing Configuration
```gradle
android {
    signingConfigs {
        release {
            storeFile file("otphub.keystore")
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias "otphub"
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

---

## 🎨 UI Design Tips

### Color Scheme (Dark Theme)
```kotlin
// ui/theme/Color.kt
val PrimaryBlue = Color(0xFF2467EC)
val AccentCyan = Color(0xFF00E1FF)
val SuccessGreen = Color(0xFF00D084)
val BackgroundDark = Color(0xFF070C15)
val CardDark = Color(0xFF0A1220)
```

### Key UI Components
1. **Dashboard**: Stats cards, recent OTPs, quick actions
2. **OTP Inbox**: List with copy button, read/unread indicators
3. **Phone Numbers**: Cards with status, verify button
4. **Subscription**: Plan cards with pricing, upgrade button
5. **Settings**: Profile, notifications, logout

---

## 📱 Testing Checklist

- [ ] SMS received when app is closed
- [ ] OTP extraction works correctly
- [ ] Push notifications received
- [ ] Login/Register flow works
- [ ] In-app purchases work (test mode)
- [ ] App works on different screen sizes
- [ ] Battery optimization handled
- [ ] Error states handled gracefully

---

**Ready to publish on Google Play Store!** 🚀
