import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Shield, Zap, Smartphone, Lock, ChevronDown, 
  Check, Menu, X, MessageSquare, Clock, Globe,
  ArrowRight, Star, Users, Server
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { SubscriptionPlan, AdminSettings } from '@/types';

interface LandingPageProps {
  subscriptionPlans: SubscriptionPlan[];
  adminSettings: AdminSettings;
}

// Animated background component
const DataStreamBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const lines: { x: number; y: number; speed: number; opacity: number }[] = [];
    const lineCount = 50;

    for (let i = 0; i < lineCount; i++) {
      lines.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        speed: 0.5 + Math.random() * 1.5,
        opacity: 0.1 + Math.random() * 0.3
      });
    }

    let animationId: number;

    const animate = () => {
      ctx.fillStyle = 'rgba(7, 12, 21, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      lines.forEach(line => {
        ctx.beginPath();
        ctx.moveTo(line.x, line.y);
        ctx.lineTo(line.x, line.y - 20);
        ctx.strokeStyle = `rgba(0, 225, 255, ${line.opacity})`;
        ctx.lineWidth = 1;
        ctx.stroke();

        line.y -= line.speed;
        if (line.y < 0) {
          line.y = canvas.height;
          line.x = Math.random() * canvas.width;
        }
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 z-0"
      style={{ background: 'linear-gradient(180deg, #070c15 0%, #0a1220 100%)' }}
    />
  );
};

// Navigation Component
const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-[#0a1220]/90 backdrop-blur-xl border-b border-white/5'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center">
              <MessageSquare className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-bold text-white">OTP<span className="text-[#00e1ff]">Hub</span></span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {['Features', 'How It Works', 'Pricing', 'FAQ'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase().replace(/\s+/g, '-'))}
                className="text-white/70 hover:text-white transition-colors text-sm font-medium"
              >
                {item}
              </button>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate('/auth')}
              className="text-white/70 hover:text-white hover:bg-white/10"
            >
              Sign In
            </Button>
            <Button
              onClick={() => navigate('/auth')}
              className="bg-gradient-to-r from-[#2467ec] to-[#1a52c4] hover:shadow-lg hover:shadow-[#2467ec]/30 text-white"
            >
              Get Started
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden text-white p-2"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-[#0a1220]/95 backdrop-blur-xl border-t border-white/10 py-4">
            {['Features', 'How It Works', 'Pricing', 'FAQ'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase().replace(/\s+/g, '-'))}
                className="block w-full text-left px-4 py-3 text-white/70 hover:text-white hover:bg-white/5 transition-colors"
              >
                {item}
              </button>
            ))}
            <div className="px-4 pt-4 space-y-2">
              <Button
                variant="outline"
                onClick={() => navigate('/auth')}
                className="w-full border-white/20 text-white hover:bg-white/10"
              >
                Sign In
              </Button>
              <Button
                onClick={() => navigate('/auth')}
                className="w-full bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white"
              >
                Get Started
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

// Hero Section
const HeroSection = () => {
  const navigate = useNavigate();

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      <DataStreamBackground />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#070c15]/50 to-[#070c15] z-10" />
      
      {/* Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#2467ec]/20 border border-[#2467ec]/30 mb-6">
              <span className="w-2 h-2 rounded-full bg-[#00e1ff] animate-pulse" />
              <span className="text-sm text-[#00e1ff]">End-to-End Encrypted</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              All your messages.
              <br />
              <span className="gradient-text">In one secure hub.</span>
            </h1>
            
            <p className="text-lg text-white/60 mb-8 max-w-xl mx-auto lg:mx-0">
              Aggregate OTPs and notifications from all your devices into one encrypted, 
              real-time stream. Never miss a verification code again.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                size="lg"
                onClick={() => navigate('/auth')}
                className="bg-gradient-to-r from-[#2467ec] to-[#1a52c4] hover:shadow-lg hover:shadow-[#2467ec]/30 text-white px-8"
              >
                Start Free Trial
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-white/20 text-white hover:bg-white/10 px-8"
              >
                Learn More
              </Button>
            </div>
            
            {/* Trust Badges */}
            <div className="mt-12 flex flex-wrap items-center justify-center lg:justify-start gap-6">
              <div className="flex items-center gap-2 text-white/40 text-sm">
                <Shield className="w-4 h-4" />
                <span>Bank-grade security</span>
              </div>
              <div className="flex items-center gap-2 text-white/40 text-sm">
                <Users className="w-4 h-4" />
                <span>10,000+ users</span>
              </div>
              <div className="flex items-center gap-2 text-white/40 text-sm">
                <Star className="w-4 h-4" />
                <span>4.9/5 rating</span>
              </div>
            </div>
          </div>
          
          {/* Right Content - Phone Mockup */}
          <div className="relative flex justify-center">
            <div className="relative animate-float">
              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-[#2467ec]/30 to-[#00e1ff]/30 blur-3xl rounded-full scale-150" />
              
              {/* Phone Frame */}
              <div className="relative bg-gradient-to-b from-[#1a2744] to-[#0a1220] rounded-[3rem] p-3 shadow-2xl border border-white/10">
                <div className="bg-[#070c15] rounded-[2.5rem] overflow-hidden w-[280px] sm:w-[320px]">
                  {/* Phone Header */}
                  <div className="bg-gradient-to-r from-[#2467ec] to-[#00e1ff] p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-white font-semibold">OTP Hub</span>
                      <div className="flex gap-1">
                        <div className="w-2 h-2 rounded-full bg-white/50" />
                        <div className="w-2 h-2 rounded-full bg-white/50" />
                        <div className="w-2 h-2 rounded-full bg-white" />
                      </div>
                    </div>
                  </div>
                  
                  {/* Phone Content */}
                  <div className="p-4 space-y-3">
                    {/* OTP Messages */}
                    {[
                      { sender: 'Amazon', code: '847291', time: '2m ago', color: '#ff9900' },
                      { sender: 'Google', code: '529384', time: '15m ago', color: '#4285f4' },
                      { sender: 'Microsoft', code: '718293', time: '1h ago', color: '#00a4ef' },
                    ].map((otp, i) => (
                      <div
                        key={i}
                        className="bg-white/5 rounded-xl p-3 border border-white/10 animate-slide-up"
                        style={{ animationDelay: `${i * 200}ms` }}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                              style={{ backgroundColor: `${otp.color}30`, color: otp.color }}
                            >
                              {otp.sender[0]}
                            </div>
                            <span className="text-white text-sm font-medium">{otp.sender}</span>
                          </div>
                          <span className="text-white/40 text-xs">{otp.time}</span>
                        </div>
                        <div className="text-2xl font-bold text-white tracking-wider">
                          {otp.code}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Phone Bottom */}
                  <div className="p-4 border-t border-white/10">
                    <div className="flex justify-around">
                      <div className="w-12 h-1 rounded-full bg-white/20" />
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating Elements */}
              <div className="absolute -top-4 -right-4 bg-[#00d084]/20 border border-[#00d084]/30 rounded-lg px-3 py-2 animate-pulse">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#00d084]" />
                  <span className="text-[#00d084] text-xs font-medium">Encrypted</span>
                </div>
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-[#2467ec]/20 border border-[#2467ec]/30 rounded-lg px-3 py-2">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-[#00e1ff]" />
                  <span className="text-[#00e1ff] text-xs font-medium">Real-time</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Features Section
const FeaturesSection = () => {
  const features = [
    {
      icon: Lock,
      title: 'End-to-End Encryption',
      description: 'Your messages are encrypted with AES-256 before they leave your device. Only you can read them.',
      color: '#00d084'
    },
    {
      icon: Zap,
      title: 'Real-Time Sync',
      description: 'Receive OTPs instantly across all your devices. No delays, no waiting.',
      color: '#00e1ff'
    },
    {
      icon: Smartphone,
      title: 'Multi-Device Support',
      description: 'Connect keypad phones, smartphones, and landlines. All in one place.',
      color: '#2467ec'
    },
    {
      icon: Shield,
      title: 'Bank-Grade Security',
      description: 'SOC 2 Type II certified infrastructure with 99.99% uptime guarantee.',
      color: '#ff6b6b'
    },
    {
      icon: Clock,
      title: 'Auto-Expiry',
      description: 'OTPs automatically expire after 10 minutes. Your inbox stays clean.',
      color: '#ffd93d'
    },
    {
      icon: Globe,
      title: 'Global Coverage',
      description: 'Support for phone numbers from 150+ countries worldwide.',
      color: '#a855f7'
    }
  ];

  return (
    <section id="features" className="relative py-24 bg-[#070c15]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Why choose <span className="gradient-text">OTPHub</span>?
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto">
            Built with security and convenience in mind. Experience the future of message aggregation.
          </p>
        </div>
        
        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group glass-card p-6 hover:border-white/20 transition-all duration-500"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div 
                className="feature-icon mb-4 group-hover:scale-110 transition-transform duration-300"
                style={{ backgroundColor: `${feature.color}20`, color: feature.color }}
              >
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-white/60 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// How It Works Section
const HowItWorksSection = () => {
  const steps = [
    {
      number: '01',
      title: 'Connect Your Devices',
      description: 'Add your phone numbers to OTPHub. We support smartphones, keypad phones, and even landlines.',
      icon: Smartphone,
      color: '#2467ec'
    },
    {
      number: '02',
      title: 'Secure Encryption',
      description: 'All messages are encrypted with your unique key before reaching our servers.',
      icon: Lock,
      color: '#00d084'
    },
    {
      number: '03',
      title: 'Receive in Real-Time',
      description: 'OTPs appear instantly in your unified inbox. Copy, share, or auto-fill with one click.',
      icon: Zap,
      color: '#00e1ff'
    }
  ];

  return (
    <section id="how-it-works" className="relative py-24 bg-[#0a1220]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            How it <span className="gradient-text">works</span>
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto">
            Get started in minutes. Three simple steps to secure message aggregation.
          </p>
        </div>
        
        {/* Steps */}
        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-[#2467ec] via-[#00e1ff] to-[#00d084] opacity-30" />
          
          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="glass-card p-8 text-center hover:border-white/20 transition-all duration-500 group">
                  {/* Step Number */}
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                      style={{ backgroundColor: step.color, color: '#fff' }}
                    >
                      {step.number}
                    </div>
                  </div>
                  
                  {/* Icon */}
                  <div 
                    className="w-16 h-16 rounded-2xl mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                    style={{ backgroundColor: `${step.color}20` }}
                  >
                    <step.icon className="w-8 h-8" style={{ color: step.color }} />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-white mb-3">{step.title}</h3>
                  <p className="text-white/60 text-sm leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// Pricing Section
const PricingSection = ({ plans }: { plans: SubscriptionPlan[] }) => {
  const [isYearly, setIsYearly] = useState(false);
  const navigate = useNavigate();

  return (
    <section id="pricing" className="relative py-24 bg-[#070c15]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Simple, transparent <span className="gradient-text">pricing</span>
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto mb-8">
            Choose the plan that fits your needs. All plans include end-to-end encryption.
          </p>
          
          {/* Toggle */}
          <div className="inline-flex items-center gap-4 p-1 rounded-full bg-white/5 border border-white/10">
            <button
              onClick={() => setIsYearly(false)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                !isYearly ? 'bg-[#2467ec] text-white' : 'text-white/60 hover:text-white'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setIsYearly(true)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 ${
                isYearly ? 'bg-[#2467ec] text-white' : 'text-white/60 hover:text-white'
              }`}
            >
              Yearly
              <span className="text-xs bg-[#00d084] text-[#070c15] px-2 py-0.5 rounded-full">
                Save 20%
              </span>
            </button>
          </div>
        </div>
        
        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`subscription-card ${plan.isPopular ? 'featured' : ''} hover:border-white/20 transition-all duration-500`}
            >
              {plan.isPopular && (
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-[#2467ec] to-[#00e1ff] text-white text-center text-xs font-medium py-1">
                  Most Popular
                </div>
              )}
              
              <div className={`${plan.isPopular ? 'pt-6' : ''}`}>
                <h3 className="text-lg font-semibold text-white mb-1">{plan.name}</h3>
                <p className="text-white/50 text-sm mb-4">{plan.description}</p>
                
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">
                    ${isYearly ? plan.price.yearly : plan.price.monthly}
                  </span>
                  <span className="text-white/50 text-sm">/{isYearly ? 'year' : 'month'}</span>
                </div>
                
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                      <Check className="w-4 h-4 text-[#00d084] flex-shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <Button
                  onClick={() => navigate('/auth')}
                  className={`w-full ${
                    plan.isPopular
                      ? 'bg-gradient-to-r from-[#2467ec] to-[#1a52c4] hover:shadow-lg hover:shadow-[#2467ec]/30'
                      : 'bg-white/10 hover:bg-white/20'
                  } text-white`}
                >
                  Get Started
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// FAQ Section
const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'Is my data secure?',
      answer: 'Absolutely. We use AES-256 encryption for all messages, the same standard used by banks and governments. Your encryption keys are generated on your device and never leave it. Even we cannot read your messages.'
    },
    {
      question: 'Can I use multiple phone numbers?',
      answer: 'Yes! Depending on your plan, you can connect multiple phone numbers. The Free plan supports 1 number, Basic supports 3, Pro supports 10, and Enterprise offers unlimited numbers.'
    },
    {
      question: 'What devices are supported?',
      answer: 'We support all types of phones - smartphones (iOS/Android), keypad phones, and even landlines. As long as your device can receive SMS, it can work with OTPHub.'
    },
    {
      question: 'How does the real-time sync work?',
      answer: 'When an OTP is received on any of your connected devices, it is instantly encrypted and pushed to your OTPHub inbox via WebSocket connections. This happens in milliseconds.'
    },
    {
      question: 'Can I cancel my subscription anytime?',
      answer: 'Yes, you can cancel your subscription at any time. Your access will continue until the end of your billing period. We also offer a 30-day money-back guarantee.'
    },
    {
      question: 'Do you offer an API?',
      answer: 'Yes! Pro and Enterprise plans include API access, allowing you to integrate OTPHub into your own applications and workflows. Check our API documentation for details.'
    }
  ];

  return (
    <section id="faq" className="relative py-24 bg-[#0a1220]">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Frequently asked <span className="gradient-text">questions</span>
          </h2>
          <p className="text-white/60">
            Everything you need to know about OTPHub.
          </p>
        </div>
        
        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="glass-card overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-4 text-left"
              >
                <span className="text-white font-medium pr-4">{faq.question}</span>
                <ChevronDown 
                  className={`w-5 h-5 text-white/50 flex-shrink-0 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`} 
                />
              </button>
              
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-4 pb-4 text-white/60 text-sm leading-relaxed">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Footer
const Footer = () => {
  return (
    <footer className="relative bg-[#070c15] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center">
                <MessageSquare className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold text-white">OTP<span className="text-[#00e1ff]">Hub</span></span>
            </div>
            <p className="text-white/50 text-sm mb-4">
              Secure communication for the modern world. Aggregate all your OTPs in one encrypted hub.
            </p>
            <div className="flex gap-4">
              {['Twitter', 'LinkedIn', 'GitHub'].map((social) => (
                <button
                  key={social}
                  className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-white/50 hover:text-white hover:bg-white/10 transition-all"
                >
                  <Server className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>
          
          {/* Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Product</h4>
            <ul className="space-y-2">
              {['Features', 'Pricing', 'API', 'Security'].map((item) => (
                <li key={item}>
                  <button className="text-white/50 hover:text-white text-sm transition-colors">
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              {['About', 'Blog', 'Careers', 'Contact'].map((item) => (
                <li key={item}>
                  <button className="text-white/50 hover:text-white text-sm transition-colors">
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Legal</h4>
            <ul className="space-y-2">
              {['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'GDPR'].map((item) => (
                <li key={item}>
                  <button className="text-white/50 hover:text-white text-sm transition-colors">
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Bottom */}
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/40 text-sm">
            © 2024 OTPHub. All rights reserved.
          </p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#00d084]" />
            <span className="text-white/40 text-sm">All systems operational</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

// Main Landing Page Component
const LandingPage = ({ subscriptionPlans }: LandingPageProps) => {
  return (
    <div className="min-h-screen bg-[#070c15]">
      <Navigation />
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <PricingSection plans={subscriptionPlans.filter(p => p.isActive)} />
      <FAQSection />
      <Footer />
    </div>
  );
};

export default LandingPage;
