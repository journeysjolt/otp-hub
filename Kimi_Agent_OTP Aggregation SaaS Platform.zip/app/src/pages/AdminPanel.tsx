import { useState } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Users, CreditCard, Settings, Shield, MessageSquare,
  Bell, Search, Menu, LogOut, Trash2, Edit, Plus,
  ChevronRight, TrendingUp, TrendingDown,
  DollarSign, AlertCircle,
  Lock, Globe, Palette, Save,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { User, SubscriptionPlan, SupportTicket, Payment, AdminSettings, HelpArticle, HelpCategory } from '@/types';

interface AdminPanelProps {
  user: User;
  users: User[];
  subscriptionPlans: SubscriptionPlan[];
  tickets: SupportTicket[];
  payments: Payment[];
  adminSettings: AdminSettings;
  helpArticles: HelpArticle[];
  helpCategories: HelpCategory[];
  onLogout: () => void;
  onUpdateUser: (userId: string, updates: Partial<User>) => void;
  onDeleteUser: (userId: string) => void;
  onUpdateSubscriptionPlan: (planId: string, updates: Partial<SubscriptionPlan>) => void;
  onUpdateAdminSettings: (updates: Partial<AdminSettings>) => void;
  onAddTicketResponse: (ticketId: string, message: string) => void;
  onUpdateTicketStatus: (ticketId: string, status: SupportTicket['status']) => void;
  onAssignTicket: (ticketId: string, adminName: string) => void;
}

// Sidebar Component
const Sidebar = ({ user, onLogout, isMobileOpen, setIsMobileOpen }: { user: User; onLogout: () => void; isMobileOpen: boolean; setIsMobileOpen: (open: boolean) => void }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { path: '/admin', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/admin/users', icon: Users, label: 'Users' },
    { path: '/admin/subscriptions', icon: CreditCard, label: 'Subscriptions' },
    { path: '/admin/tickets', icon: MessageSquare, label: 'Support Tickets' },
    { path: '/admin/payments', icon: DollarSign, label: 'Payments' },
    { path: '/admin/settings', icon: Settings, label: 'Settings' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      {isMobileOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsMobileOpen(false)} />
      )}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-[#0a1220] border-r border-white/5 transform transition-transform duration-300 lg:transform-none ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="h-16 flex items-center px-6 border-b border-white/5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center mr-3">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <span className="text-xl font-bold text-white">Admin<span className="text-[#00e1ff]">Panel</span></span>
        </div>

        <div className="p-4 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white font-semibold">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-medium truncate">{user.name}</p>
              <p className="text-white/50 text-sm truncate">{user.role}</p>
            </div>
          </div>
        </div>

        <nav className="p-4 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.path}
              onClick={() => { navigate(item.path); setIsMobileOpen(false); }}
              className={`sidebar-item w-full ${isActive(item.path) ? 'active' : ''}`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/5">
          <button onClick={onLogout} className="sidebar-item w-full text-red-400 hover:text-red-300 hover:bg-red-500/10">
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
};

// Header Component
const Header = ({ onMenuClick, user }: { onMenuClick: () => void; user: User }) => {
  return (
    <header className="h-16 bg-[#0a1220]/80 backdrop-blur-xl border-b border-white/5 flex items-center justify-between px-4 lg:px-6">
      <div className="flex items-center gap-4">
        <button onClick={onMenuClick} className="lg:hidden p-2 text-white/60 hover:text-white">
          <Menu className="w-6 h-6" />
        </button>
        <div className="hidden sm:flex items-center gap-2 text-white/40 text-sm">
          <span>Admin</span>
          <ChevronRight className="w-4 h-4" />
          <span className="text-white">Dashboard</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="relative p-2 text-white/60 hover:text-white">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-[#00e1ff] rounded-full" />
        </button>
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white font-semibold text-sm">
          {user.name.charAt(0).toUpperCase()}
        </div>
      </div>
    </header>
  );
};

// Admin Dashboard
const AdminDashboard = ({ users, tickets, payments, subscriptionPlans }: { users: User[]; tickets: SupportTicket[]; payments: Payment[]; subscriptionPlans: SubscriptionPlan[] }) => {
  const stats = [
    { label: 'Total Users', value: users.length, change: '+12%', trend: 'up', icon: Users, color: '#2467ec' },
    { label: 'Active Subscriptions', value: users.filter(u => u.subscription !== 'free').length, change: '+8%', trend: 'up', icon: CreditCard, color: '#00d084' },
    { label: 'Total Revenue', value: `$${payments.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0)}`, change: '+15%', trend: 'up', icon: DollarSign, color: '#00e1ff' },
    { label: 'Pending Tickets', value: tickets.filter(t => t.status === 'open').length, change: '-3%', trend: 'down', icon: MessageSquare, color: '#ffd93d' },
  ];

  const recentUsers = users.slice(0, 5);
  const recentPayments = payments.slice(0, 5);
  const pendingTickets = tickets.filter(t => t.status === 'open').slice(0, 5);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-white/60">Welcome back, here's what's happening today</p>
      </div>

      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <div key={index} className="glass-card p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${stat.color}20` }}>
                <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
              </div>
              <div className={`flex items-center gap-1 text-xs ${stat.trend === 'up' ? 'text-[#00d084]' : 'text-red-400'}`}>
                {stat.trend === 'up' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {stat.change}
              </div>
            </div>
            <div className="text-2xl font-bold text-white">{stat.value}</div>
            <div className="text-white/50 text-sm">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Revenue Chart Placeholder */}
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Revenue Overview</h3>
            <select className="bg-white/5 border border-white/10 rounded-lg px-3 py-1 text-sm text-white">
              <option>This Month</option>
              <option>Last Month</option>
              <option>This Year</option>
            </select>
          </div>
          <div className="h-48 flex items-end justify-between gap-2">
            {[40, 65, 45, 80, 55, 90, 70, 85, 60, 75, 95, 88].map((h, i) => (
              <div key={i} className="flex-1 bg-gradient-to-t from-[#2467ec] to-[#00e1ff] rounded-t" style={{ height: `${h}%`, opacity: 0.3 + (h / 200) }} />
            ))}
          </div>
          <div className="flex justify-between mt-2 text-xs text-white/40">
            <span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span><span>Jun</span>
            <span>Jul</span><span>Aug</span><span>Sep</span><span>Oct</span><span>Nov</span><span>Dec</span>
          </div>
        </div>

        {/* Subscription Distribution */}
        <div className="glass-card p-6">
          <h3 className="text-white font-semibold mb-4">Subscription Distribution</h3>
          <div className="space-y-4">
            {subscriptionPlans.map((plan) => {
              const count = users.filter(u => u.subscription === plan.id).length;
              const percentage = (count / users.length) * 100;
              return (
                <div key={plan.id}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-white">{plan.name}</span>
                    <span className="text-white/60">{count} ({percentage.toFixed(0)}%)</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-[#2467ec] to-[#00e1ff] rounded-full transition-all" style={{ width: `${percentage}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Users */}
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Recent Users</h3>
            <button className="text-[#00e1ff] text-sm hover:underline">View All</button>
          </div>
          <div className="space-y-3">
            {recentUsers.map((u) => (
              <div key={u.id} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white text-sm font-semibold">
                  {u.name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm truncate">{u.name}</p>
                  <p className="text-white/40 text-xs truncate">{u.email}</p>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-xs ${u.isActive ? 'bg-[#00d084]/20 text-[#00d084]' : 'bg-red-500/20 text-red-400'}`}>
                  {u.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Payments */}
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Recent Payments</h3>
            <button className="text-[#00e1ff] text-sm hover:underline">View All</button>
          </div>
          <div className="space-y-3">
            {recentPayments.map((p) => (
              <div key={p.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#00d084]/20 flex items-center justify-center">
                    <DollarSign className="w-4 h-4 text-[#00d084]" />
                  </div>
                  <div>
                    <p className="text-white text-sm">{p.userName}</p>
                    <p className="text-white/40 text-xs">{p.planId} - {p.billingCycle}</p>
                  </div>
                </div>
                <span className="text-white font-medium">${p.amount}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Pending Tickets */}
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Pending Tickets</h3>
            <button className="text-[#00e1ff] text-sm hover:underline">View All</button>
          </div>
          <div className="space-y-3">
            {pendingTickets.length === 0 ? (
              <p className="text-white/40 text-sm">No pending tickets</p>
            ) : (
              pendingTickets.map((t) => (
                <div key={t.id} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#ffd93d]/20 flex items-center justify-center flex-shrink-0">
                    <AlertCircle className="w-4 h-4 text-[#ffd93d]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm truncate">{t.subject}</p>
                    <p className="text-white/40 text-xs">{t.userName} • {t.category}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Users Management
const UsersManagement = ({ users, onUpdateUser, onDeleteUser }: { users: User[]; onUpdateUser: (userId: string, updates: Partial<User>) => void; onDeleteUser: (userId: string) => void }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<'all' | 'user' | 'admin'>('all');
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const filteredUsers = users.filter(u => {
    const matchesSearch = u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || u.role === filterRole;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Users</h1>
          <p className="text-white/60">Manage user accounts and permissions</p>
        </div>
        <Button className="bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white">
          <Plus className="w-4 h-4 mr-2" />
          Add User
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
          <input
            type="text"
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field w-full pl-10"
          />
        </div>
        <select
          value={filterRole}
          onChange={(e) => setFilterRole(e.target.value as any)}
          className="input-field"
        >
          <option value="all">All Roles</option>
          <option value="user">User</option>
          <option value="admin">Admin</option>
        </select>
      </div>

      {/* Users Table */}
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left text-white/60 font-medium text-sm p-4">User</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Role</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Subscription</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Status</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Joined</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((u) => (
                <tr key={u.id} className="border-b border-white/5 hover:bg-white/5">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white font-semibold">
                        {u.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-white font-medium">{u.name}</p>
                        <p className="text-white/40 text-sm">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded-full text-xs capitalize ${u.role === 'admin' ? 'bg-[#2467ec]/20 text-[#00e1ff]' : 'bg-white/10 text-white/60'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className="px-2 py-1 rounded-full text-xs bg-white/10 text-white/60 capitalize">
                      {u.subscription}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded-full text-xs ${u.isActive ? 'bg-[#00d084]/20 text-[#00d084]' : 'bg-red-500/20 text-red-400'}`}>
                      {u.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="p-4 text-white/60 text-sm">
                    {new Date(u.createdAt).toLocaleDateString()}
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <button onClick={() => setEditingUser(u)} className="p-2 rounded-lg bg-white/5 text-white/60 hover:text-white hover:bg-white/10">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button onClick={() => onDeleteUser(u.id)} className="p-2 rounded-lg bg-white/5 text-white/60 hover:text-red-400 hover:bg-red-500/10">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="glass-card w-full max-w-md p-6">
            <h2 className="text-xl font-bold text-white mb-4">Edit User</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-white/60 mb-2">Name</label>
                <input
                  type="text"
                  defaultValue={editingUser.name}
                  className="input-field w-full"
                  onChange={(e) => onUpdateUser(editingUser.id, { name: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-2">Email</label>
                <input
                  type="email"
                  defaultValue={editingUser.email}
                  className="input-field w-full"
                  onChange={(e) => onUpdateUser(editingUser.id, { email: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-2">Role</label>
                <select
                  defaultValue={editingUser.role}
                  className="input-field w-full"
                  onChange={(e) => onUpdateUser(editingUser.id, { role: e.target.value as any })}
                >
                  <option value="user">User</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-2">Subscription</label>
                <select
                  defaultValue={editingUser.subscription}
                  className="input-field w-full"
                  onChange={(e) => onUpdateUser(editingUser.id, { subscription: e.target.value as any })}
                >
                  <option value="free">Free</option>
                  <option value="basic">Basic</option>
                  <option value="pro">Pro</option>
                  <option value="enterprise">Enterprise</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setEditingUser(null)} className="flex-1 py-2 rounded-lg bg-white/5 text-white hover:bg-white/10">
                Cancel
              </button>
              <button onClick={() => setEditingUser(null)} className="flex-1 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Subscriptions Management
const SubscriptionsManagement = ({ plans, onUpdatePlan }: { plans: SubscriptionPlan[]; onUpdatePlan: (planId: string, updates: Partial<SubscriptionPlan>) => void }) => {
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Subscriptions</h1>
        <p className="text-white/60">Manage subscription plans and pricing</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map((plan) => (
          <div key={plan.id} className={`glass-card p-5 ${plan.isPopular ? 'border-[#00e1ff]/50' : ''}`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">{plan.name}</h3>
              {plan.isPopular && <span className="px-2 py-0.5 bg-[#00e1ff] text-[#070c15] text-xs rounded">Popular</span>}
            </div>
            <div className="mb-4">
              <span className="text-2xl font-bold text-white">${plan.price.monthly}</span>
              <span className="text-white/40 text-sm">/mo</span>
            </div>
            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/60">Phone Numbers</span>
                <span className="text-white">{plan.limits.phoneNumbers === -1 ? '∞' : plan.limits.phoneNumbers}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/60">OTPs/Month</span>
                <span className="text-white">{plan.limits.otpPerMonth === -1 ? '∞' : plan.limits.otpPerMonth}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/60">Storage</span>
                <span className="text-white">{plan.limits.storageDays} days</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setEditingPlan(plan)} className="flex-1 py-2 rounded-lg bg-white/5 text-white hover:bg-white/10 text-sm">
                Edit
              </button>
              <button
                onClick={() => onUpdatePlan(plan.id, { isActive: !plan.isActive })}
                className={`px-3 py-2 rounded-lg text-sm ${plan.isActive ? 'bg-[#00d084]/20 text-[#00d084]' : 'bg-red-500/20 text-red-400'}`}
              >
                {plan.isActive ? 'Active' : 'Inactive'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Plan Modal */}
      {editingPlan && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="glass-card w-full max-w-md p-6">
            <h2 className="text-xl font-bold text-white mb-4">Edit Plan: {editingPlan.name}</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-white/60 mb-2">Monthly Price</label>
                  <input
                    type="number"
                    defaultValue={editingPlan.price.monthly}
                    className="input-field w-full"
                    onChange={(e) => onUpdatePlan(editingPlan.id, { price: { ...editingPlan.price, monthly: Number(e.target.value) } })}
                  />
                </div>
                <div>
                  <label className="block text-sm text-white/60 mb-2">Yearly Price</label>
                  <input
                    type="number"
                    defaultValue={editingPlan.price.yearly}
                    className="input-field w-full"
                    onChange={(e) => onUpdatePlan(editingPlan.id, { price: { ...editingPlan.price, yearly: Number(e.target.value) } })}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-2">Description</label>
                <input
                  type="text"
                  defaultValue={editingPlan.description}
                  className="input-field w-full"
                  onChange={(e) => onUpdatePlan(editingPlan.id, { description: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm text-white/60 mb-2">Max Phones</label>
                  <input
                    type="number"
                    defaultValue={editingPlan.limits.phoneNumbers}
                    className="input-field w-full"
                    onChange={(e) => onUpdatePlan(editingPlan.id, { limits: { ...editingPlan.limits, phoneNumbers: Number(e.target.value) } })}
                  />
                </div>
                <div>
                  <label className="block text-sm text-white/60 mb-2">Max OTPs</label>
                  <input
                    type="number"
                    defaultValue={editingPlan.limits.otpPerMonth}
                    className="input-field w-full"
                    onChange={(e) => onUpdatePlan(editingPlan.id, { limits: { ...editingPlan.limits, otpPerMonth: Number(e.target.value) } })}
                  />
                </div>
                <div>
                  <label className="block text-sm text-white/60 mb-2">Storage Days</label>
                  <input
                    type="number"
                    defaultValue={editingPlan.limits.storageDays}
                    className="input-field w-full"
                    onChange={(e) => onUpdatePlan(editingPlan.id, { limits: { ...editingPlan.limits, storageDays: Number(e.target.value) } })}
                  />
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setEditingPlan(null)} className="flex-1 py-2 rounded-lg bg-white/5 text-white hover:bg-white/10">
                Cancel
              </button>
              <button onClick={() => setEditingPlan(null)} className="flex-1 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Tickets Management
const TicketsManagement = ({ tickets, users, onAddResponse, onUpdateStatus, onAssign }: { tickets: SupportTicket[]; users: User[]; onAddResponse: (ticketId: string, message: string) => void; onUpdateStatus: (ticketId: string, status: SupportTicket['status']) => void; onAssign: (ticketId: string, adminName: string) => void }) => {
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [responseText, setResponseText] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | SupportTicket['status']>('all');

  const filteredTickets = tickets.filter(t => filterStatus === 'all' || t.status === filterStatus);

  const handleSubmitResponse = () => {
    if (!selectedTicket || !responseText.trim()) return;
    onAddResponse(selectedTicket.id, responseText);
    setResponseText('');
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Support Tickets</h1>
          <p className="text-white/60">Manage customer support requests</p>
        </div>
        <div className="flex items-center gap-2">
          {['all', 'open', 'in-progress', 'resolved', 'closed'].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status as any)}
              className={`px-3 py-1.5 rounded-lg text-sm capitalize ${filterStatus === status ? 'bg-[#2467ec] text-white' : 'bg-white/5 text-white/60 hover:bg-white/10'}`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Tickets List */}
        <div className="lg:col-span-1 space-y-3">
          {filteredTickets.map((ticket) => (
            <button
              key={ticket.id}
              onClick={() => setSelectedTicket(ticket)}
              className={`w-full glass-card p-4 text-left hover:border-white/20 transition-all ${selectedTicket?.id === ticket.id ? 'border-[#2467ec]' : ''}`}
            >
              <div className="flex items-start justify-between mb-2">
                <span className={`px-2 py-0.5 rounded-full text-xs ${
                  ticket.status === 'open' ? 'bg-[#ffd93d]/20 text-[#ffd93d]' :
                  ticket.status === 'in-progress' ? 'bg-[#2467ec]/20 text-[#00e1ff]' :
                  ticket.status === 'resolved' ? 'bg-[#00d084]/20 text-[#00d084]' :
                  'bg-white/10 text-white/40'
                }`}>
                  {ticket.status}
                </span>
                <span className={`px-2 py-0.5 rounded-full text-xs ${
                  ticket.priority === 'urgent' ? 'bg-red-500/20 text-red-400' :
                  ticket.priority === 'high' ? 'bg-orange-500/20 text-orange-400' :
                  ticket.priority === 'medium' ? 'bg-[#ffd93d]/20 text-[#ffd93d]' :
                  'bg-white/10 text-white/40'
                }`}>
                  {ticket.priority}
                </span>
              </div>
              <h4 className="text-white font-medium text-sm mb-1 line-clamp-1">{ticket.subject}</h4>
              <p className="text-white/40 text-xs">{ticket.userName} • {new Date(ticket.createdAt).toLocaleDateString()}</p>
            </button>
          ))}
        </div>

        {/* Ticket Detail */}
        <div className="lg:col-span-2">
          {selectedTicket ? (
            <div className="glass-card p-6">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-white font-semibold text-lg mb-1">{selectedTicket.subject}</h3>
                  <p className="text-white/40 text-sm">{selectedTicket.userName} ({selectedTicket.userEmail})</p>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={selectedTicket.status}
                    onChange={(e) => onUpdateStatus(selectedTicket.id, e.target.value as any)}
                    className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white"
                  >
                    <option value="open">Open</option>
                    <option value="in-progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                    <option value="closed">Closed</option>
                  </select>
                  <select
                    value={selectedTicket.assignedTo || ''}
                    onChange={(e) => onAssign(selectedTicket.id, e.target.value)}
                    className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white"
                  >
                    <option value="">Unassigned</option>
                    {users.filter(u => u.role === 'admin').map(u => (
                      <option key={u.id} value={u.name}>{u.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4 mb-6">
                <p className="text-white/80 text-sm">{selectedTicket.description}</p>
                <div className="flex items-center gap-4 mt-3 text-xs text-white/40">
                  <span>Category: {selectedTicket.category}</span>
                  <span>Created: {new Date(selectedTicket.createdAt).toLocaleString()}</span>
                </div>
              </div>

              {/* Responses */}
              <div className="space-y-4 mb-6">
                {selectedTicket.responses.map((response) => (
                  <div key={response.id} className={`flex gap-4 ${response.userRole === 'admin' ? 'flex-row' : 'flex-row-reverse'}`}>
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white text-sm font-semibold flex-shrink-0">
                      {response.userName.charAt(0).toUpperCase()}
                    </div>
                    <div className={`flex-1 rounded-lg p-4 ${response.userRole === 'admin' ? 'bg-[#2467ec]/20' : 'bg-white/5'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-medium text-sm">{response.userName}</span>
                        <span className="text-white/40 text-xs">{new Date(response.createdAt).toLocaleString()}</span>
                      </div>
                      <p className="text-white/80 text-sm">{response.message}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Response */}
              <div className="flex gap-3">
                <textarea
                  value={responseText}
                  onChange={(e) => setResponseText(e.target.value)}
                  placeholder="Type your response..."
                  className="input-field flex-1 resize-none"
                  rows={3}
                />
                <button
                  onClick={handleSubmitResponse}
                  className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white self-end"
                >
                  Send
                </button>
              </div>
            </div>
          ) : (
            <div className="glass-card p-12 text-center">
              <MessageSquare className="w-16 h-16 text-white/20 mx-auto mb-4" />
              <p className="text-white/40">Select a ticket to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Payments Management
const PaymentsManagement = ({ payments }: { payments: Payment[] }) => {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Payments</h1>
        <p className="text-white/60">View and manage payment transactions</p>
      </div>

      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left text-white/60 font-medium text-sm p-4">Transaction ID</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">User</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Plan</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Amount</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Method</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Status</th>
                <th className="text-left text-white/60 font-medium text-sm p-4">Date</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p.id} className="border-b border-white/5 hover:bg-white/5">
                  <td className="p-4 text-white/60 text-sm font-mono">{p.transactionId}</td>
                  <td className="p-4">
                    <div>
                      <p className="text-white text-sm">{p.userName}</p>
                      <p className="text-white/40 text-xs">{p.userEmail}</p>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="text-white text-sm capitalize">{p.planId}</span>
                    <span className="text-white/40 text-xs ml-2">({p.billingCycle})</span>
                  </td>
                  <td className="p-4 text-white font-medium">${p.amount}</td>
                  <td className="p-4 text-white/60 text-sm capitalize">{p.paymentMethod}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      p.status === 'completed' ? 'bg-[#00d084]/20 text-[#00d084]' :
                      p.status === 'pending' ? 'bg-[#ffd93d]/20 text-[#ffd93d]' :
                      p.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                      'bg-white/10 text-white/40'
                    }`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="p-4 text-white/60 text-sm">{new Date(p.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Admin Settings
const AdminSettingsPanel = ({ settings, onUpdateSettings }: { settings: AdminSettings; onUpdateSettings: (updates: Partial<AdminSettings>) => void }) => {
  const [localSettings, setLocalSettings] = useState(settings);

  const handleSave = () => {
    onUpdateSettings(localSettings);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Settings</h1>
          <p className="text-white/60">Configure your application settings</p>
        </div>
        <Button onClick={handleSave} className="bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white">
          <Save className="w-4 h-4 mr-2" />
          Save Changes
        </Button>
      </div>

      {/* General Settings */}
      <div className="glass-card p-6">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <Globe className="w-5 h-5 text-[#00e1ff]" />
          General Settings
        </h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-white/60 mb-2">Site Name</label>
            <input
              type="text"
              value={localSettings.siteName}
              onChange={(e) => setLocalSettings({ ...localSettings, siteName: e.target.value })}
              className="input-field w-full"
            />
          </div>
          <div>
            <label className="block text-sm text-white/60 mb-2">Support Email</label>
            <input
              type="email"
              value={localSettings.supportEmail}
              onChange={(e) => setLocalSettings({ ...localSettings, supportEmail: e.target.value })}
              className="input-field w-full"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-sm text-white/60 mb-2">Site Description</label>
            <textarea
              value={localSettings.siteDescription}
              onChange={(e) => setLocalSettings({ ...localSettings, siteDescription: e.target.value })}
              className="input-field w-full resize-none"
              rows={2}
            />
          </div>
        </div>
      </div>

      {/* Appearance */}
      <div className="glass-card p-6">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <Palette className="w-5 h-5 text-[#00e1ff]" />
          Appearance
        </h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-white/60 mb-2">Primary Color</label>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={localSettings.primaryColor}
                onChange={(e) => setLocalSettings({ ...localSettings, primaryColor: e.target.value })}
                className="w-12 h-10 rounded-lg bg-transparent border-0 cursor-pointer"
              />
              <input
                type="text"
                value={localSettings.primaryColor}
                onChange={(e) => setLocalSettings({ ...localSettings, primaryColor: e.target.value })}
                className="input-field flex-1"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm text-white/60 mb-2">Accent Color</label>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={localSettings.accentColor}
                onChange={(e) => setLocalSettings({ ...localSettings, accentColor: e.target.value })}
                className="w-12 h-10 rounded-lg bg-transparent border-0 cursor-pointer"
              />
              <input
                type="text"
                value={localSettings.accentColor}
                onChange={(e) => setLocalSettings({ ...localSettings, accentColor: e.target.value })}
                className="input-field flex-1"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="glass-card p-6">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <Zap className="w-5 h-5 text-[#00e1ff]" />
          Features
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white text-sm">Enable Registration</p>
              <p className="text-white/40 text-xs">Allow new users to sign up</p>
            </div>
            <button
              onClick={() => setLocalSettings({ ...localSettings, enableRegistration: !localSettings.enableRegistration })}
              className={`relative w-12 h-6 rounded-full transition-colors ${localSettings.enableRegistration ? 'bg-[#00d084]' : 'bg-white/20'}`}
            >
              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${localSettings.enableRegistration ? 'translate-x-6' : 'translate-x-0.5'}`} />
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white text-sm">Enable Social Login</p>
              <p className="text-white/40 text-xs">Allow login with Google, GitHub, etc.</p>
            </div>
            <button
              onClick={() => setLocalSettings({ ...localSettings, enableSocialLogin: !localSettings.enableSocialLogin })}
              className={`relative w-12 h-6 rounded-full transition-colors ${localSettings.enableSocialLogin ? 'bg-[#00d084]' : 'bg-white/20'}`}
            >
              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${localSettings.enableSocialLogin ? 'translate-x-6' : 'translate-x-0.5'}`} />
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white text-sm">Maintenance Mode</p>
              <p className="text-white/40 text-xs">Temporarily disable the site for maintenance</p>
            </div>
            <button
              onClick={() => setLocalSettings({ ...localSettings, maintenanceMode: !localSettings.maintenanceMode })}
              className={`relative w-12 h-6 rounded-full transition-colors ${localSettings.maintenanceMode ? 'bg-[#ffd93d]' : 'bg-white/20'}`}
            >
              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${localSettings.maintenanceMode ? 'translate-x-6' : 'translate-x-0.5'}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Limits */}
      <div className="glass-card p-6">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <Lock className="w-5 h-5 text-[#00e1ff]" />
          Plan Limits
        </h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm text-white/60 mb-2">Free - Max Phones</label>
            <input
              type="number"
              value={localSettings.maxPhoneNumbersFree}
              onChange={(e) => setLocalSettings({ ...localSettings, maxPhoneNumbersFree: Number(e.target.value) })}
              className="input-field w-full"
            />
          </div>
          <div>
            <label className="block text-sm text-white/60 mb-2">Basic - Max Phones</label>
            <input
              type="number"
              value={localSettings.maxPhoneNumbersBasic}
              onChange={(e) => setLocalSettings({ ...localSettings, maxPhoneNumbersBasic: Number(e.target.value) })}
              className="input-field w-full"
            />
          </div>
          <div>
            <label className="block text-sm text-white/60 mb-2">Pro - Max Phones</label>
            <input
              type="number"
              value={localSettings.maxPhoneNumbersPro}
              onChange={(e) => setLocalSettings({ ...localSettings, maxPhoneNumbersPro: Number(e.target.value) })}
              className="input-field w-full"
            />
          </div>
          <div>
            <label className="block text-sm text-white/60 mb-2">Enterprise - Max Phones</label>
            <input
              type="number"
              value={localSettings.maxPhoneNumbersEnterprise}
              onChange={(e) => setLocalSettings({ ...localSettings, maxPhoneNumbersEnterprise: Number(e.target.value) })}
              className="input-field w-full"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

// Main Admin Panel Component
const AdminPanel = (props: AdminPanelProps) => {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#070c15] flex">
      <Sidebar user={props.user} onLogout={props.onLogout} isMobileOpen={isMobileSidebarOpen} setIsMobileOpen={setIsMobileSidebarOpen} />
      <div className="flex-1 flex flex-col min-w-0">
        <Header onMenuClick={() => setIsMobileSidebarOpen(true)} user={props.user} />
        <main className="flex-1 overflow-auto">
          <Routes>
            <Route path="/" element={<AdminDashboard users={props.users} tickets={props.tickets} payments={props.payments} subscriptionPlans={props.subscriptionPlans} />} />
            <Route path="/users" element={<UsersManagement users={props.users} onUpdateUser={props.onUpdateUser} onDeleteUser={props.onDeleteUser} />} />
            <Route path="/subscriptions" element={<SubscriptionsManagement plans={props.subscriptionPlans} onUpdatePlan={props.onUpdateSubscriptionPlan} />} />
            <Route path="/tickets" element={<TicketsManagement tickets={props.tickets} users={props.users} onAddResponse={props.onAddTicketResponse} onUpdateStatus={props.onUpdateTicketStatus} onAssign={props.onAssignTicket} />} />
            <Route path="/payments" element={<PaymentsManagement payments={props.payments} />} />
            <Route path="/settings" element={<AdminSettingsPanel settings={props.adminSettings} onUpdateSettings={props.onUpdateAdminSettings} />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default AdminPanel;
