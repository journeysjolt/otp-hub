import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, MessageSquare, Plus, Clock, CheckCircle, AlertCircle,
  XCircle, Send
} from 'lucide-react';
import type { User, SupportTicket } from '@/types';

interface TicketsPageProps {
  user: User;
  tickets: SupportTicket[];
  onCreateTicket: (subject: string, description: string, category: SupportTicket['category'], priority: SupportTicket['priority']) => void;
  onAddTicketResponse: (ticketId: string, message: string) => void;
}

const TicketsPage = ({ user, tickets, onCreateTicket, onAddTicketResponse }: TicketsPageProps) => {
  const navigate = useNavigate();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [responseText, setResponseText] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | SupportTicket['status']>('all');

  // Create ticket form state
  const [newTicket, setNewTicket] = useState({
    subject: '',
    description: '',
    category: 'technical' as SupportTicket['category'],
    priority: 'medium' as SupportTicket['priority']
  });

  const filteredTickets = tickets.filter(t => filterStatus === 'all' || t.status === filterStatus);

  const handleCreateTicket = () => {
    if (!newTicket.subject.trim() || !newTicket.description.trim()) return;
    onCreateTicket(newTicket.subject, newTicket.description, newTicket.category, newTicket.priority);
    setShowCreateModal(false);
    setNewTicket({ subject: '', description: '', category: 'technical', priority: 'medium' });
  };

  const handleSubmitResponse = () => {
    if (!selectedTicket || !responseText.trim()) return;
    onAddTicketResponse(selectedTicket.id, responseText);
    setResponseText('');
    // Update the selected ticket with the new response
    setSelectedTicket({
      ...selectedTicket,
      responses: [
        ...selectedTicket.responses,
        {
          id: Date.now().toString(),
          ticketId: selectedTicket.id,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          message: responseText,
          createdAt: new Date()
        }
      ]
    });
  };

  const getStatusIcon = (status: SupportTicket['status']) => {
    switch (status) {
      case 'open': return <AlertCircle className="w-4 h-4 text-[#ffd93d]" />;
      case 'in-progress': return <Clock className="w-4 h-4 text-[#00e1ff]" />;
      case 'resolved': return <CheckCircle className="w-4 h-4 text-[#00d084]" />;
      case 'closed': return <XCircle className="w-4 h-4 text-white/40" />;
    }
  };

  const getStatusColor = (status: SupportTicket['status']) => {
    switch (status) {
      case 'open': return 'bg-[#ffd93d]/20 text-[#ffd93d]';
      case 'in-progress': return 'bg-[#2467ec]/20 text-[#00e1ff]';
      case 'resolved': return 'bg-[#00d084]/20 text-[#00d084]';
      case 'closed': return 'bg-white/10 text-white/40';
    }
  };

  const getPriorityColor = (priority: SupportTicket['priority']) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500/20 text-red-400';
      case 'high': return 'bg-orange-500/20 text-orange-400';
      case 'medium': return 'bg-[#ffd93d]/20 text-[#ffd93d]';
      case 'low': return 'bg-white/10 text-white/40';
    }
  };

  return (
    <div className="min-h-screen bg-[#070c15]">
      {/* Header */}
      <header className="bg-[#0a1220]/80 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button onClick={() => navigate(-1)} className="p-2 text-white/60 hover:text-white">
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-white">Support Tickets</h1>
                <p className="text-white/50 text-sm">Get help from our support team</p>
              </div>
            </div>
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white text-sm font-medium"
            >
              <Plus className="w-4 h-4" />
              New Ticket
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { label: 'All Tickets', value: tickets.length, filter: 'all' as const },
            { label: 'Open', value: tickets.filter(t => t.status === 'open').length, filter: 'open' as const },
            { label: 'In Progress', value: tickets.filter(t => t.status === 'in-progress').length, filter: 'in-progress' as const },
            { label: 'Resolved', value: tickets.filter(t => t.status === 'resolved').length, filter: 'resolved' as const },
          ].map((stat) => (
            <button
              key={stat.label}
              onClick={() => setFilterStatus(stat.filter)}
              className={`glass-card p-4 text-center transition-all ${filterStatus === stat.filter ? 'border-[#2467ec]' : ''}`}
            >
              <div className="text-2xl font-bold text-white">{stat.value}</div>
              <div className="text-white/50 text-sm">{stat.label}</div>
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Tickets List */}
          <div className="lg:col-span-1 space-y-3">
            {filteredTickets.length === 0 ? (
              <div className="glass-card p-8 text-center">
                <MessageSquare className="w-12 h-12 text-white/20 mx-auto mb-3" />
                <p className="text-white/50 text-sm">No tickets found</p>
              </div>
            ) : (
              filteredTickets.map((ticket) => (
                <button
                  key={ticket.id}
                  onClick={() => setSelectedTicket(ticket)}
                  className={`w-full glass-card p-4 text-left hover:border-white/20 transition-all ${selectedTicket?.id === ticket.id ? 'border-[#2467ec]' : ''}`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(ticket.status)}
                      <span className={`px-2 py-0.5 rounded-full text-xs ${getStatusColor(ticket.status)}`}>
                        {ticket.status}
                      </span>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-xs ${getPriorityColor(ticket.priority)}`}>
                      {ticket.priority}
                    </span>
                  </div>
                  <h4 className="text-white font-medium text-sm mb-1 line-clamp-1">{ticket.subject}</h4>
                  <p className="text-white/40 text-xs capitalize">{ticket.category} • {new Date(ticket.createdAt).toLocaleDateString()}</p>
                  {ticket.responses.length > 0 && (
                    <div className="flex items-center gap-1 mt-2 text-[#00e1ff] text-xs">
                      <MessageSquare className="w-3 h-3" />
                      {ticket.responses.length} {ticket.responses.length === 1 ? 'response' : 'responses'}
                    </div>
                  )}
                </button>
              ))
            )}
          </div>

          {/* Ticket Detail */}
          <div className="lg:col-span-2">
            {selectedTicket ? (
              <div className="glass-card">
                {/* Ticket Header */}
                <div className="p-6 border-b border-white/5">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(selectedTicket.status)}`}>
                          {selectedTicket.status}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs ${getPriorityColor(selectedTicket.priority)}`}>
                          {selectedTicket.priority}
                        </span>
                      </div>
                      <h2 className="text-white font-semibold text-lg">{selectedTicket.subject}</h2>
                    </div>
                    <div className="text-right">
                      <p className="text-white/40 text-xs">Ticket #{selectedTicket.id.slice(-6)}</p>
                      <p className="text-white/40 text-xs">{new Date(selectedTicket.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-white/40">
                    <span className="capitalize">Category: {selectedTicket.category}</span>
                    {selectedTicket.assignedTo && <span>Assigned to: {selectedTicket.assignedTo}</span>}
                  </div>
                </div>

                {/* Original Message */}
                <div className="p-6 border-b border-white/5">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white font-semibold flex-shrink-0">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-medium">{user.name}</span>
                        <span className="text-white/40 text-xs">{new Date(selectedTicket.createdAt).toLocaleString()}</span>
                      </div>
                      <p className="text-white/80 text-sm">{selectedTicket.description}</p>
                    </div>
                  </div>
                </div>

                {/* Responses */}
                <div className="p-6 space-y-6 max-h-96 overflow-y-auto">
                  {selectedTicket.responses.map((response) => (
                    <div key={response.id} className="flex gap-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0 ${response.userRole === 'admin' || response.userRole === 'superadmin' ? 'bg-gradient-to-br from-[#00d084] to-[#00e1ff]' : 'bg-gradient-to-br from-[#2467ec] to-[#00e1ff]'}`}>
                        {response.userName.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-white font-medium">{response.userName}</span>
                            {(response.userRole === 'admin' || response.userRole === 'superadmin') && (
                              <span className="px-2 py-0.5 bg-[#2467ec]/20 text-[#00e1ff] text-xs rounded">Support Team</span>
                            )}
                          </div>
                          <span className="text-white/40 text-xs">{new Date(response.createdAt).toLocaleString()}</span>
                        </div>
                        <p className="text-white/80 text-sm">{response.message}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add Response */}
                {selectedTicket.status !== 'closed' && selectedTicket.status !== 'resolved' && (
                  <div className="p-6 border-t border-white/5">
                    <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white font-semibold flex-shrink-0">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1">
                        <textarea
                          value={responseText}
                          onChange={(e) => setResponseText(e.target.value)}
                          placeholder="Type your message..."
                          className="input-field w-full resize-none mb-3"
                          rows={3}
                        />
                        <div className="flex justify-end">
                          <button
                            onClick={handleSubmitResponse}
                            disabled={!responseText.trim()}
                            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white text-sm font-medium disabled:opacity-50"
                          >
                            <Send className="w-4 h-4" />
                            Send Message
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="glass-card p-12 text-center">
                <MessageSquare className="w-16 h-16 text-white/20 mx-auto mb-4" />
                <h3 className="text-white font-medium mb-2">Select a ticket</h3>
                <p className="text-white/50 text-sm mb-4">Choose a ticket from the list to view details</p>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white text-sm"
                >
                  Create New Ticket
                </button>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Create Ticket Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="glass-card w-full max-w-lg p-6">
            <h2 className="text-xl font-bold text-white mb-4">Create Support Ticket</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-white/60 mb-2">Subject *</label>
                <input
                  type="text"
                  value={newTicket.subject}
                  onChange={(e) => setNewTicket({ ...newTicket, subject: e.target.value })}
                  placeholder="Brief description of your issue"
                  className="input-field w-full"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-white/60 mb-2">Category *</label>
                  <select
                    value={newTicket.category}
                    onChange={(e) => setNewTicket({ ...newTicket, category: e.target.value as any })}
                    className="input-field w-full"
                  >
                    <option value="technical">Technical Issue</option>
                    <option value="billing">Billing</option>
                    <option value="account">Account</option>
                    <option value="feature">Feature Request</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-white/60 mb-2">Priority *</label>
                  <select
                    value={newTicket.priority}
                    onChange={(e) => setNewTicket({ ...newTicket, priority: e.target.value as any })}
                    className="input-field w-full"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-2">Description *</label>
                <textarea
                  value={newTicket.description}
                  onChange={(e) => setNewTicket({ ...newTicket, description: e.target.value })}
                  placeholder="Please provide as much detail as possible..."
                  className="input-field w-full resize-none"
                  rows={5}
                />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 py-2 rounded-lg bg-white/5 text-white hover:bg-white/10"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateTicket}
                disabled={!newTicket.subject.trim() || !newTicket.description.trim()}
                className="flex-1 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white disabled:opacity-50"
              >
                Create Ticket
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TicketsPage;
