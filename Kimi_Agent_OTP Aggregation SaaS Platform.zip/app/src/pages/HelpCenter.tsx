import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search, MessageSquare, ChevronRight, ArrowLeft,
  Shield, CreditCard, Smartphone, Lock, FileText,
  ThumbsUp, ThumbsDown, HelpCircle, Rocket,
  Wrench, AlertCircle, User as UserIcon
} from 'lucide-react';
import type { HelpArticle, HelpCategory, User } from '@/types';

interface HelpCenterProps {
  helpArticles: HelpArticle[];
  helpCategories: HelpCategory[];
  isAuthenticated: boolean;
  user?: User | null;
}

const iconMap: Record<string, React.ElementType> = {
  Rocket,
  CreditCard,
  Shield,
  Wrench,
  Smartphone,
  Lock,
  User: UserIcon,
  FileText,
  HelpCircle,
  AlertCircle,
};

const HelpCenter = ({ helpArticles, helpCategories, isAuthenticated }: HelpCenterProps) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<HelpArticle | null>(null);

  const filteredArticles = helpArticles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const popularArticles = helpArticles.sort((a, b) => b.views - a.views).slice(0, 5);

  if (selectedArticle) {
    return (
      <div className="min-h-screen bg-[#070c15]">
        {/* Header */}
        <header className="bg-[#0a1220]/80 backdrop-blur-xl border-b border-white/5">
          <div className="max-w-4xl mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <button onClick={() => setSelectedArticle(null)} className="p-2 text-white/60 hover:text-white">
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="flex-1">
                <div className="flex items-center gap-2 text-sm text-white/40 mb-1">
                  <span>Help Center</span>
                  <ChevronRight className="w-4 h-4" />
                  <span>{selectedArticle.category}</span>
                </div>
                <h1 className="text-xl font-bold text-white">{selectedArticle.title}</h1>
              </div>
            </div>
          </div>
        </header>

        {/* Article Content */}
        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="glass-card p-8">
            <div className="prose prose-invert max-w-none">
              <p className="text-white/80 leading-relaxed">{selectedArticle.content}</p>
              <p className="text-white/80 leading-relaxed mt-4">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
              </p>
              <h3 className="text-white font-semibold text-lg mt-6 mb-3">Getting Started</h3>
              <p className="text-white/80 leading-relaxed">
                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
                Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
              </p>
              <h3 className="text-white font-semibold text-lg mt-6 mb-3">Step-by-Step Guide</h3>
              <ol className="list-decimal list-inside space-y-2 text-white/80">
                <li>First, navigate to your dashboard</li>
                <li>Click on the settings icon in the top right</li>
                <li>Select the option you want to configure</li>
                <li>Save your changes</li>
              </ol>
              <div className="bg-[#2467ec]/10 border border-[#2467ec]/30 rounded-lg p-4 mt-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-[#00e1ff] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white font-medium text-sm">Pro Tip</p>
                    <p className="text-white/60 text-sm mt-1">
                      Make sure to verify your email address before making any changes to your account settings.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Feedback */}
            <div className="border-t border-white/10 mt-8 pt-6">
              <p className="text-white text-sm mb-4">Was this article helpful?</p>
              <div className="flex items-center gap-3">
                <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 hover:text-white transition-colors">
                  <ThumbsUp className="w-4 h-4" />
                  Yes
                </button>
                <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 hover:text-white transition-colors">
                  <ThumbsDown className="w-4 h-4" />
                  No
                </button>
              </div>
            </div>
          </div>

          {/* Related Articles */}
          <div className="mt-8">
            <h3 className="text-white font-semibold mb-4">Related Articles</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {helpArticles.filter(a => a.id !== selectedArticle.id && a.category === selectedArticle.category).slice(0, 4).map((article) => (
                <button
                  key={article.id}
                  onClick={() => setSelectedArticle(article)}
                  className="glass-card p-4 text-left hover:border-white/20 transition-all"
                >
                  <h4 className="text-white font-medium text-sm mb-1">{article.title}</h4>
                  <p className="text-white/40 text-xs">{article.views} views</p>
                </button>
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#070c15]">
      {/* Header */}
      <header className="bg-gradient-to-b from-[#0a1220] to-transparent">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-8">
            <button onClick={() => navigate('/')} className="flex items-center gap-2 text-white/60 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
              Back to Home
            </button>
            {isAuthenticated && (
              <button
                onClick={() => navigate('/tickets')}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#2467ec]/20 text-[#00e1ff] hover:bg-[#2467ec]/30 transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                My Tickets
              </button>
            )}
          </div>

          <div className="text-center max-w-2xl mx-auto">
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">How can we help you?</h1>
            <p className="text-white/60 mb-8">Search our knowledge base or browse categories below</p>
            
            {/* Search */}
            <div className="relative max-w-xl mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
              <input
                type="text"
                placeholder="Search for answers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field w-full pl-12 pr-4 py-4 text-lg"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Categories */}
        {!searchTerm && !selectedCategory && (
          <>
            <h2 className="text-xl font-semibold text-white mb-6">Browse by Category</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
              {helpCategories.map((category) => {
                const Icon = iconMap[category.icon] || HelpCircle;
                return (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.name)}
                    className="glass-card p-6 text-left hover:border-white/20 transition-all group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-[#2467ec]/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6 text-[#00e1ff]" />
                    </div>
                    <h3 className="text-white font-semibold mb-1">{category.name}</h3>
                    <p className="text-white/50 text-sm mb-3">{category.description}</p>
                    <p className="text-white/40 text-xs">{category.articleCount} articles</p>
                  </button>
                );
              })}
            </div>

            {/* Popular Articles */}
            <h2 className="text-xl font-semibold text-white mb-6">Popular Articles</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {popularArticles.map((article) => (
                <button
                  key={article.id}
                  onClick={() => setSelectedArticle(article)}
                  className="glass-card p-4 text-left hover:border-white/20 transition-all"
                >
                  <div className="flex items-start gap-3">
                    <FileText className="w-5 h-5 text-[#00e1ff] flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-white font-medium text-sm mb-2 line-clamp-2">{article.title}</h4>
                      <div className="flex items-center gap-3 text-xs text-white/40">
                        <span>{article.views} views</span>
                        <span>{article.helpful}% helpful</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </>
        )}

        {/* Search Results */}
        {(searchTerm || selectedCategory) && (
          <>
            <div className="flex items-center gap-4 mb-6">
              {selectedCategory && (
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="text-white/60 hover:text-white"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
              )}
              <h2 className="text-xl font-semibold text-white">
                {searchTerm ? `Search results for "${searchTerm}"` : selectedCategory}
              </h2>
            </div>
            
            {filteredArticles.length === 0 ? (
              <div className="glass-card p-12 text-center">
                <Search className="w-16 h-16 text-white/20 mx-auto mb-4" />
                <h3 className="text-white font-medium mb-2">No results found</h3>
                <p className="text-white/50 text-sm mb-4">Try different keywords or browse categories</p>
                {isAuthenticated && (
                  <button
                    onClick={() => navigate('/tickets')}
                    className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white text-sm"
                  >
                    Contact Support
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredArticles.map((article) => (
                  <button
                    key={article.id}
                    onClick={() => setSelectedArticle(article)}
                    className="w-full glass-card p-4 text-left hover:border-white/20 transition-all flex items-center justify-between"
                  >
                    <div className="flex items-start gap-4">
                      <FileText className="w-5 h-5 text-[#00e1ff] flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-white font-medium mb-1">{article.title}</h4>
                        <p className="text-white/50 text-sm line-clamp-1">{article.content}</p>
                        <div className="flex items-center gap-3 mt-2 text-xs text-white/40">
                          <span>{article.category}</span>
                          <span>{article.views} views</span>
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-white/40" />
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {/* Contact Support CTA */}
        <div className="glass-card p-8 mt-12 text-center">
          <MessageSquare className="w-12 h-12 text-[#00e1ff] mx-auto mb-4" />
          <h3 className="text-white font-semibold text-lg mb-2">Still need help?</h3>
          <p className="text-white/60 mb-4">Can't find what you're looking for? Our support team is here to help.</p>
          {isAuthenticated ? (
            <button
              onClick={() => navigate('/tickets')}
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white font-medium"
            >
              Contact Support
            </button>
          ) : (
            <button
              onClick={() => navigate('/auth')}
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white font-medium"
            >
              Sign In to Contact Support
            </button>
          )}
        </div>
      </main>
    </div>
  );
};

export default HelpCenter;
