import { useState } from 'react';
import { Routes, Route, useNavigate, Link } from 'react-router-dom';
import {
  LayoutDashboard, Smartphone, CreditCard, Settings as SettingsIcon, Shield,
  Bell, Menu, LogOut, Copy, Check, Trash2, Plus, Lock, ChevronRight,
  Key, Fingerprint, CheckCircle, MessageSquare, HelpCircle,
  TrendingUp, Wallet, Receipt
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { User, PhoneNumber, OTPMessage, SubscriptionPlan, SupportTicket, SubscriptionTier, Payment } from '@/types';

interface DashboardProps {
  user: User;
  phoneNumbers: PhoneNumber[];
  otpMessages: OTPMessage[];
  subscriptionPlans: SubscriptionPlan[];
  tickets: SupportTicket[];
  onLogout: () => void;
  onAddPhoneNumber: (number: string, label: string, deviceType: 'keypad' | 'smartphone') => void;
  onDeletePhoneNumber: (id: string) => void;
  onTogglePhoneStatus: (id: string) => void;
  onMarkAsRead: (otpId: string) => void;
  onDeleteOTP: (otpId: string) => void;
  onUpgradeSubscription: (tier: string) => void;
  onProcessPayment: (planId: SubscriptionTier, billingCycle: 'monthly' | 'yearly', paymentMethod: Payment['paymentMethod']) => void;
  onCreateTicket: (subject: string, description: string, category: SupportTicket['category'], priority: SupportTicket['priority']) => void;
  onAddTicketResponse: (ticketId: string, message: string) => void;
}

// Sidebar Component
const Sidebar = ({ 
  user, 
  onLogout, 
  isMobileOpen, 
  setIsMobileOpen 
}: { 
  user: User; 
  onLogout: () => void;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}) => {
  const navigate = useNavigate();

  const menuItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Overview' },
    { path: '/dashboard/inbox', icon: Shield, label: 'OTP Inbox' },
    { path: '/dashboard/phones', icon: Smartphone, label: 'Phone Numbers' },
    { path: '/dashboard/subscription', icon: CreditCard, label: 'Subscription' },
    { path: '/dashboard/security', icon: Lock, label: 'Security' },
    { path: '/dashboard/settings', icon: SettingsIcon, label: 'Settings' },
  ];

  return (
    <>
      {isMobileOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsMobileOpen(false)} />
      )}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-[#0a1220] border-r border-white/5 transform transition-transform duration-300 lg:transform-none ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="h-16 flex items-center px-6 border-b border-white/5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center mr-3">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <span className="text-xl font-bold text-white">OTP<span className="text-[#00e1ff]">Hub</span></span>
        </div>

        <div className="p-4 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white font-semibold">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-medium truncate">{user.name}</p>
              <p className="text-white/50 text-sm truncate">{user.email}</p>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize ${
              user.subscription === 'pro' || user.subscription === 'enterprise'
                ? 'bg-[#00e1ff]/20 text-[#00e1ff]'
                : 'bg-white/10 text-white/60'
            }`}>
              {user.subscription}
            </span>
          </div>
        </div>

        <nav className="p-4 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.path}
              onClick={() => { navigate(item.path); setIsMobileOpen(false); }}
              className="sidebar-item w-full"
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5 space-y-1">
          <Link to="/tickets" className="sidebar-item w-full" onClick={() => setIsMobileOpen(false)}>
            <MessageSquare className="w-5 h-5" />
            <span>Support Tickets</span>
          </Link>
          <Link to="/help" className="sidebar-item w-full" onClick={() => setIsMobileOpen(false)}>
            <HelpCircle className="w-5 h-5" />
            <span>Help Center</span>
          </Link>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/5">
          <button onClick={onLogout} className="sidebar-item w-full text-red-400 hover:text-red-300 hover:bg-red-500/10">
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
};

// Header Component
const Header = ({ onMenuClick, user }: { onMenuClick: () => void; user: User }) => {
  return (
    <header className="h-16 bg-[#0a1220]/80 backdrop-blur-xl border-b border-white/5 flex items-center justify-between px-4 lg:px-6">
      <div className="flex items-center gap-4">
        <button onClick={onMenuClick} className="lg:hidden p-2 text-white/60 hover:text-white">
          <Menu className="w-6 h-6" />
        </button>
      </div>

      <div className="flex items-center gap-4">
        <Link to="/tickets" className="relative p-2 text-white/60 hover:text-white">
          <MessageSquare className="w-5 h-5" />
        </Link>
        <button className="relative p-2 text-white/60 hover:text-white">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-[#00e1ff] rounded-full" />
        </button>
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#2467ec] to-[#00e1ff] flex items-center justify-center text-white font-semibold text-sm">
          {user.name.charAt(0).toUpperCase()}
        </div>
      </div>
    </header>
  );
};

// Overview Dashboard
const Overview = ({ user, phoneNumbers, otpMessages, tickets }: { user: User; phoneNumbers: PhoneNumber[]; otpMessages: OTPMessage[]; tickets: SupportTicket[] }) => {
  const navigate = useNavigate();
  const stats = [
    { label: 'Active Numbers', value: phoneNumbers.filter(p => p.isActive).length, total: phoneNumbers.length, icon: Smartphone, color: '#2467ec' },
    { label: 'Total OTPs', value: otpMessages.length, icon: Shield, color: '#00e1ff' },
    { label: 'Unread OTPs', value: otpMessages.filter(o => !o.isRead).length, icon: Bell, color: '#ffd93d' },
    { label: 'Open Tickets', value: tickets.filter(t => t.status === 'open').length, icon: MessageSquare, color: '#00d084' },
  ];

  const recentOTPs = otpMessages.slice(0, 5);

  return (
    <div className="p-6 space-y-6">
      <div className="glass-card p-6">
        <h1 className="text-2xl font-bold text-white mb-2">Welcome back, {user.name}!</h1>
        <p className="text-white/60">
          You have {otpMessages.filter(o => !o.isRead).length} unread OTPs from {phoneNumbers.filter(p => p.isActive).length} active numbers.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <div key={index} className="glass-card p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${stat.color}20` }}>
                <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
              </div>
              {stat.total !== undefined && <span className="text-white/40 text-sm">of {stat.total}</span>}
            </div>
            <div className="text-2xl font-bold text-white">{stat.value}</div>
            <div className="text-white/50 text-sm">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Recent OTPs</h2>
            <button onClick={() => navigate('/dashboard/inbox')} className="text-[#00e1ff] text-sm hover:underline">View All</button>
          </div>
          <div className="space-y-3">
            {recentOTPs.map((otp) => (
              <div key={otp.id} className={`flex items-center justify-between p-4 rounded-lg border ${otp.isRead ? 'bg-white/5 border-white/5' : 'bg-[#2467ec]/10 border-[#2467ec]/30'}`}>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold" style={{ backgroundColor: otp.isRead ? 'rgba(255,255,255,0.1)' : 'rgba(36, 103, 236, 0.3)', color: otp.isRead ? '#fff' : '#00e1ff' }}>
                    {otp.sender[0]}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-medium">{otp.sender}</span>
                      {!otp.isRead && <span className="w-2 h-2 rounded-full bg-[#00e1ff]" />}
                    </div>
                    <div className="text-white/50 text-sm">{otp.phoneNumber}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-white tracking-wider">{otp.code}</div>
                  <div className="text-white/40 text-xs">{new Date(otp.receivedAt).toLocaleTimeString()}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Quick Actions</h2>
          </div>
          <div className="space-y-3">
            {[
              { label: 'Add Phone Number', icon: Plus, color: '#2467ec', action: () => navigate('/dashboard/phones') },
              { label: 'Upgrade Plan', icon: TrendingUp, color: '#00d084', action: () => navigate('/dashboard/subscription') },
              { label: 'Contact Support', icon: MessageSquare, color: '#00e1ff', action: () => navigate('/tickets') },
              { label: 'View Help Center', icon: HelpCircle, color: '#ffd93d', action: () => navigate('/help') },
            ].map((action, index) => (
              <button key={index} onClick={action.action} className="w-full glass-card p-4 flex items-center gap-4 hover:border-white/20 transition-all group">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform" style={{ backgroundColor: `${action.color}20` }}>
                  <action.icon className="w-6 h-6" style={{ color: action.color }} />
                </div>
                <span className="text-white font-medium">{action.label}</span>
                <ChevronRight className="w-5 h-5 text-white/40 ml-auto group-hover:text-white transition-colors" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// OTP Inbox, Phone Numbers, Security, Settings components remain similar but updated...
// I'll include the key updated components

// Subscription Component with Payment
const Subscription = ({ 
  user, 
  plans,
  onProcessPayment
}: { 
  user: User;
  plans: SubscriptionPlan[];
  onProcessPayment: (planId: SubscriptionTier, billingCycle: 'monthly' | 'yearly', paymentMethod: Payment['paymentMethod']) => void;
}) => {
  const [isYearly, setIsYearly] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<Payment['paymentMethod']>('card');
  const currentPlan = plans.find(p => p.id === user.subscription);

  const handleSelectPlan = (plan: SubscriptionPlan) => {
    if (plan.id === user.subscription) return;
    setSelectedPlan(plan);
    setShowPaymentModal(true);
  };

  const handlePayment = () => {
    if (!selectedPlan) return;
    onProcessPayment(selectedPlan.id, isYearly ? 'yearly' : 'monthly', paymentMethod);
    setShowPaymentModal(false);
    setSelectedPlan(null);
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Subscription</h1>
        <p className="text-white/60">Manage your plan and billing</p>
      </div>

      <div className="glass-card p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <p className="text-white/60 text-sm mb-1">Current Plan</p>
            <h2 className="text-2xl font-bold text-white capitalize">{user.subscription}</h2>
            {user.subscriptionExpiry && (
              <p className="text-white/50 text-sm mt-1">Renews on {user.subscriptionExpiry.toLocaleDateString()}</p>
            )}
          </div>
          <div className="flex items-center gap-3">
            <button className="px-4 py-2 rounded-lg bg-white/5 text-white hover:bg-white/10 transition-colors text-sm">
              <Receipt className="w-4 h-4 inline mr-2" />
              Billing History
            </button>
          </div>
        </div>

        {currentPlan && (
          <div className="mt-6 pt-6 border-t border-white/10">
            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <p className="text-white/40 text-sm">Phone Numbers</p>
                <p className="text-white font-semibold">{currentPlan.limits.phoneNumbers === -1 ? 'Unlimited' : currentPlan.limits.phoneNumbers}</p>
              </div>
              <div>
                <p className="text-white/40 text-sm">OTPs per Month</p>
                <p className="text-white font-semibold">{currentPlan.limits.otpPerMonth === -1 ? 'Unlimited' : currentPlan.limits.otpPerMonth}</p>
              </div>
              <div>
                <p className="text-white/40 text-sm">Storage Days</p>
                <p className="text-white font-semibold">{currentPlan.limits.storageDays}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-white">Upgrade Your Plan</h2>
          <div className="flex items-center gap-2 p-1 rounded-full bg-white/5 border border-white/10">
            <button onClick={() => setIsYearly(false)} className={`px-4 py-1.5 rounded-full text-sm transition-all ${!isYearly ? 'bg-[#2467ec] text-white' : 'text-white/60'}`}>
              Monthly
            </button>
            <button onClick={() => setIsYearly(true)} className={`px-4 py-1.5 rounded-full text-sm transition-all flex items-center gap-1 ${isYearly ? 'bg-[#2467ec] text-white' : 'text-white/60'}`}>
              Yearly
              <span className="text-xs bg-[#00d084] text-[#070c15] px-1.5 py-0.5 rounded-full">-20%</span>
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {plans.map((plan) => (
            <div key={plan.id} className={`subscription-card ${plan.isPopular ? 'featured' : ''} ${user.subscription === plan.id ? 'border-[#00d084]/50' : ''}`}>
              {user.subscription === plan.id && <div className="absolute -top-2 left-4 px-2 py-0.5 bg-[#00d084] text-[#070c15] text-xs font-medium rounded">Current</div>}
              {plan.isPopular && user.subscription !== plan.id && <div className="absolute -top-2 left-4 px-2 py-0.5 bg-[#00e1ff] text-[#070c15] text-xs font-medium rounded">Popular</div>}

              <h3 className="text-white font-semibold mb-1">{plan.name}</h3>
              <p className="text-white/50 text-sm mb-4">{plan.description}</p>

              <div className="mb-4">
                <span className="text-2xl font-bold text-white">${isYearly ? plan.price.yearly : plan.price.monthly}</span>
                <span className="text-white/40 text-sm">/{isYearly ? 'year' : 'mo'}</span>
              </div>

              <ul className="space-y-2 mb-4">
                {plan.features.slice(0, 3).map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-white/60">
                    <Check className="w-4 h-4 text-[#00d084] flex-shrink-0 mt-0.5" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleSelectPlan(plan)}
                disabled={user.subscription === plan.id}
                className={`w-full py-2 rounded-lg text-sm font-medium transition-all ${
                  user.subscription === plan.id
                    ? 'bg-[#00d084]/20 text-[#00d084] cursor-default'
                    : plan.isPopular
                    ? 'bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white hover:shadow-lg hover:shadow-[#2467ec]/30'
                    : 'bg-white/5 text-white hover:bg-white/10'
                }`}
              >
                {user.subscription === plan.id ? 'Active' : 'Upgrade'}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && selectedPlan && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="glass-card w-full max-w-md p-6">
            <h2 className="text-xl font-bold text-white mb-4">Complete Payment</h2>
            <div className="mb-6">
              <p className="text-white/60 text-sm">You are upgrading to:</p>
              <p className="text-white font-semibold text-lg">{selectedPlan.name} Plan</p>
              <p className="text-2xl font-bold text-white mt-2">${isYearly ? selectedPlan.price.yearly : selectedPlan.price.monthly}</p>
              <p className="text-white/40 text-sm">{isYearly ? 'Billed annually' : 'Billed monthly'}</p>
            </div>

            <div className="space-y-3 mb-6">
              <p className="text-white/60 text-sm">Select payment method:</p>
              {[
                { id: 'card', label: 'Credit/Debit Card', icon: CreditCard },
                { id: 'paypal', label: 'PayPal', icon: Wallet },
              ].map((method) => (
                <button
                  key={method.id}
                  onClick={() => setPaymentMethod(method.id as Payment['paymentMethod'])}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
                    paymentMethod === method.id
                      ? 'border-[#2467ec] bg-[#2467ec]/20'
                      : 'border-white/10 bg-white/5 hover:border-white/20'
                  }`}
                >
                  <method.icon className="w-5 h-5 text-white/60" />
                  <span className="text-white text-sm">{method.label}</span>
                  {paymentMethod === method.id && <Check className="w-4 h-4 text-[#00d084] ml-auto" />}
                </button>
              ))}
            </div>

            <div className="flex gap-3">
              <button onClick={() => setShowPaymentModal(false)} className="flex-1 py-2 rounded-lg bg-white/5 text-white hover:bg-white/10">
                Cancel
              </button>
              <button onClick={handlePayment} className="flex-1 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white">
                Pay Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Simple placeholder components for other routes
const OTPInbox = ({ otpMessages, onMarkAsRead, onDeleteOTP }: any) => {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'unread' | 'read'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredOTPs = otpMessages.filter((otp: OTPMessage) => {
    if (selectedFilter === 'unread' && otp.isRead) return false;
    if (selectedFilter === 'read' && !otp.isRead) return false;
    return true;
  });

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">OTP Inbox</h1>
          <p className="text-white/60">Manage all your verification codes</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {['all', 'unread', 'read'].map((filter) => (
          <button
            key={filter}
            onClick={() => setSelectedFilter(filter as any)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedFilter === filter ? 'bg-[#2467ec] text-white' : 'bg-white/5 text-white/60 hover:bg-white/10'
            }`}
          >
            {filter.charAt(0).toUpperCase() + filter.slice(1)}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filteredOTPs.map((otp: OTPMessage) => (
          <div key={otp.id} className={`glass-card p-4 ${!otp.isRead ? 'border-[#2467ec]/30' : ''}`}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold flex-shrink-0" style={{ backgroundColor: otp.isRead ? 'rgba(255,255,255,0.05)' : 'rgba(36, 103, 236, 0.2)', color: otp.isRead ? '#fff' : '#00e1ff' }}>
                  {otp.sender[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-white font-medium">{otp.sender}</span>
                    {!otp.isRead && <span className="w-2 h-2 rounded-full bg-[#00e1ff]" />}
                  </div>
                  <p className="text-white/60 text-sm mb-2">{otp.message}</p>
                  <div className="flex items-center gap-4 text-xs text-white/40">
                    <span>{otp.phoneNumber}</span>
                    <span>{new Date(otp.receivedAt).toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-3">
                <span className="text-2xl font-bold text-white tracking-wider">{otp.code}</span>
                <div className="flex items-center gap-2">
                  <button onClick={() => handleCopy(otp.code, otp.id)} className="p-2 rounded-lg bg-white/5 text-white/60 hover:text-white">
                    {copiedId === otp.id ? <Check className="w-4 h-4 text-[#00d084]" /> : <Copy className="w-4 h-4" />}
                  </button>
                  {!otp.isRead && <button onClick={() => onMarkAsRead(otp.id)} className="p-2 rounded-lg bg-white/5 text-white/60 hover:text-white"><CheckCircle className="w-4 h-4" /></button>}
                  <button onClick={() => onDeleteOTP(otp.id)} className="p-2 rounded-lg bg-white/5 text-white/60 hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const PhoneNumbers = ({ phoneNumbers, onAddPhoneNumber, onDeletePhoneNumber, onTogglePhoneStatus }: any) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newNumber, setNewNumber] = useState('');
  const [newLabel, setNewLabel] = useState('');
  const [deviceType, setDeviceType] = useState<'keypad' | 'smartphone'>('smartphone');

  const handleAdd = () => {
    if (!newNumber || !newLabel) return;
    onAddPhoneNumber(newNumber, newLabel, deviceType);
    setShowAddModal(false);
    setNewNumber('');
    setNewLabel('');
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Phone Numbers</h1>
          <p className="text-white/60">Manage your connected devices</p>
        </div>
        <Button onClick={() => setShowAddModal(true)} className="bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white">
          <Plus className="w-4 h-4 mr-2" />
          Add Number
        </Button>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {phoneNumbers.map((phone: PhoneNumber) => (
          <div key={phone.id} className="glass-card p-5">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${phone.isActive ? 'bg-[#00d084]/20' : 'bg-white/5'}`}>
                <Smartphone className={`w-6 h-6 ${phone.isActive ? 'text-[#00d084]' : 'text-white/40'}`} />
              </div>
              <span className={`px-2 py-1 rounded-full text-xs ${phone.isVerified ? 'bg-[#00d084]/20 text-[#00d084]' : 'bg-yellow-500/20 text-yellow-400'}`}>
                {phone.isVerified ? 'Verified' : 'Pending'}
              </span>
            </div>
            <h3 className="text-white font-semibold mb-1">{phone.label}</h3>
            <p className="text-white/60 text-sm mb-4">{phone.number}</p>
            <div className="flex items-center gap-2">
              <button onClick={() => onTogglePhoneStatus(phone.id)} className={`flex-1 py-2 rounded-lg text-sm font-medium ${phone.isActive ? 'bg-[#00d084]/20 text-[#00d084]' : 'bg-white/5 text-white/60'}`}>
                {phone.isActive ? 'Active' : 'Inactive'}
              </button>
              <button onClick={() => onDeletePhoneNumber(phone.id)} className="p-2 rounded-lg bg-white/5 text-white/40 hover:text-red-400">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="glass-card w-full max-w-md p-6">
            <h2 className="text-xl font-bold text-white mb-4">Add Phone Number</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-white/60 mb-2">Phone Number</label>
                <input type="tel" value={newNumber} onChange={(e) => setNewNumber(e.target.value)} placeholder="+1 (555) 123-4567" className="input-field w-full" />
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-2">Label</label>
                <input type="text" value={newLabel} onChange={(e) => setNewLabel(e.target.value)} placeholder="Personal Phone" className="input-field w-full" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => setDeviceType('smartphone')} className={`p-3 rounded-lg border text-sm ${deviceType === 'smartphone' ? 'border-[#2467ec] bg-[#2467ec]/20 text-white' : 'border-white/10 text-white/60'}`}>Smartphone</button>
                <button onClick={() => setDeviceType('keypad')} className={`p-3 rounded-lg border text-sm ${deviceType === 'keypad' ? 'border-[#2467ec] bg-[#2467ec]/20 text-white' : 'border-white/10 text-white/60'}`}>Keypad Phone</button>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowAddModal(false)} className="flex-1 py-2 rounded-lg bg-white/5 text-white">Cancel</button>
              <button onClick={handleAdd} className="flex-1 py-2 rounded-lg bg-gradient-to-r from-[#2467ec] to-[#1a52c4] text-white">Add</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const Security = () => (
  <div className="p-6 space-y-6">
    <div>
      <h1 className="text-2xl font-bold text-white">Security</h1>
      <p className="text-white/60">Protect your account and data</p>
    </div>
    <div className="glass-card p-6">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-xl bg-[#2467ec]/20 flex items-center justify-center">
          <Fingerprint className="w-6 h-6 text-[#00e1ff]" />
        </div>
        <div>
          <h3 className="text-white font-semibold">Two-Factor Authentication</h3>
          <p className="text-white/50 text-sm">Add an extra layer of security</p>
        </div>
      </div>
    </div>
    <div className="glass-card p-6">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-xl bg-[#00d084]/20 flex items-center justify-center">
          <Key className="w-6 h-6 text-[#00d084]" />
        </div>
        <div>
          <h3 className="text-white font-semibold">Encryption Key</h3>
          <p className="text-white/50 text-sm">Your personal encryption key</p>
        </div>
      </div>
    </div>
  </div>
);

const Settings = ({ user }: { user: User }) => (
  <div className="p-6 space-y-6">
    <div>
      <h1 className="text-2xl font-bold text-white">Settings</h1>
      <p className="text-white/60">Manage your account preferences</p>
    </div>
    <div className="glass-card p-6">
      <h3 className="text-white font-semibold mb-4">Profile Information</h3>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm text-white/60 mb-2">Full Name</label>
          <input type="text" defaultValue={user.name} className="input-field w-full" />
        </div>
        <div>
          <label className="block text-sm text-white/60 mb-2">Email Address</label>
          <input type="email" defaultValue={user.email} className="input-field w-full" />
        </div>
      </div>
    </div>
  </div>
);

// Main Dashboard Component
const Dashboard = (props: DashboardProps) => {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#070c15] flex">
      <Sidebar user={props.user} onLogout={props.onLogout} isMobileOpen={isMobileSidebarOpen} setIsMobileOpen={setIsMobileSidebarOpen} />
      <div className="flex-1 flex flex-col min-w-0">
        <Header onMenuClick={() => setIsMobileSidebarOpen(true)} user={props.user} />
        <main className="flex-1 overflow-auto">
          <Routes>
            <Route path="/" element={<Overview user={props.user} phoneNumbers={props.phoneNumbers} otpMessages={props.otpMessages} tickets={props.tickets} />} />
            <Route path="/inbox" element={<OTPInbox otpMessages={props.otpMessages} onMarkAsRead={props.onMarkAsRead} onDeleteOTP={props.onDeleteOTP} />} />
            <Route path="/phones" element={<PhoneNumbers phoneNumbers={props.phoneNumbers} onAddPhoneNumber={props.onAddPhoneNumber} onDeletePhoneNumber={props.onDeletePhoneNumber} onTogglePhoneStatus={props.onTogglePhoneStatus} />} />
            <Route path="/subscription" element={<Subscription user={props.user} plans={props.subscriptionPlans} onProcessPayment={props.onProcessPayment} />} />
            <Route path="/security" element={<Security />} />
            <Route path="/settings" element={<Settings user={props.user} />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
