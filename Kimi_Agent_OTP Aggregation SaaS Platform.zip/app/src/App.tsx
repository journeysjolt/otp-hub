import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

// Types
import type { User, PhoneNumber, OTPMessage, SubscriptionPlan, SupportTicket, Payment, AdminSettings, HelpArticle, HelpCategory, SubscriptionTier, TicketResponse } from '@/types';

// Pages
import LandingPage from '@/pages/LandingPage';
import Dashboard from '@/pages/Dashboard';
import AuthPage from '@/pages/AuthPage';
import AdminPanel from '@/pages/AdminPanel';
import HelpCenter from '@/pages/HelpCenter';
import TicketsPage from '@/pages/TicketsPage';

// Mock Admin Settings
const defaultAdminSettings: AdminSettings = {
  siteName: 'OTP Hub',
  siteDescription: 'Secure OTP Aggregation Platform',
  primaryColor: '#2467ec',
  accentColor: '#00e1ff',
  enableRegistration: true,
  enableSocialLogin: true,
  maintenanceMode: false,
  supportEmail: 'support@otphub.com',
  maxPhoneNumbersFree: 1,
  maxPhoneNumbersBasic: 3,
  maxPhoneNumbersPro: 10,
  maxPhoneNumbersEnterprise: -1,
};

// Mock Data
const mockSubscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free',
    price: { monthly: 0, yearly: 0 },
    description: 'Perfect for trying out OTPHub',
    features: ['1 phone number', '50 OTPs/month', '7-day storage', 'Basic encryption'],
    limits: { phoneNumbers: 1, otpPerMonth: 50, storageDays: 7 },
    isActive: true
  },
  {
    id: 'basic',
    name: 'Basic',
    price: { monthly: 9, yearly: 90 },
    description: 'For personal use',
    features: ['3 phone numbers', '500 OTPs/month', '30-day storage', 'End-to-end encryption', 'Email notifications'],
    limits: { phoneNumbers: 3, otpPerMonth: 500, storageDays: 30 },
    isActive: true
  },
  {
    id: 'pro',
    name: 'Pro',
    price: { monthly: 19, yearly: 190 },
    description: 'For power users',
    features: ['10 phone numbers', 'Unlimited OTPs', '90-day storage', 'Priority encryption', 'Real-time sync', 'API access'],
    limits: { phoneNumbers: 10, otpPerMonth: -1, storageDays: 90 },
    isPopular: true,
    isActive: true
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: { monthly: 49, yearly: 490 },
    description: 'For teams & businesses',
    features: ['Unlimited numbers', 'Unlimited OTPs', '1-year storage', 'Advanced security', 'Dedicated support', 'Custom integrations'],
    limits: { phoneNumbers: -1, otpPerMonth: -1, storageDays: 365 },
    isActive: true
  }
];

const mockUsers: User[] = [
  {
    id: '1',
    email: 'admin@otphub.com',
    name: 'Admin User',
    role: 'admin',
    subscription: 'enterprise',
    subscriptionExpiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
    createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
    lastLogin: new Date(),
    isActive: true,
    phoneNumbersCount: 5,
    totalOTPs: 1250
  },
  {
    id: '2',
    email: 'john@example.com',
    name: 'John Doe',
    role: 'user',
    subscription: 'pro',
    subscriptionExpiry: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
    lastLogin: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    isActive: true,
    phoneNumbersCount: 3,
    totalOTPs: 450
  },
  {
    id: '3',
    email: 'jane@example.com',
    name: 'Jane Smith',
    role: 'user',
    subscription: 'basic',
    subscriptionExpiry: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
    createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000),
    lastLogin: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    isActive: true,
    phoneNumbersCount: 2,
    totalOTPs: 180
  },
  {
    id: '4',
    email: 'mike@example.com',
    name: 'Mike Johnson',
    role: 'user',
    subscription: 'free',
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    lastLogin: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
    isActive: false,
    phoneNumbersCount: 1,
    totalOTPs: 25
  }
];

const mockPhoneNumbers: PhoneNumber[] = [
  {
    id: '1',
    userId: '2',
    number: '+1 (555) 123-4567',
    label: 'Personal Phone',
    countryCode: 'US',
    isActive: true,
    isVerified: true,
    deviceType: 'smartphone',
    lastSynced: new Date(),
    otpCount: 12
  },
  {
    id: '2',
    userId: '2',
    number: '+1 (555) 987-6543',
    label: 'Work Phone',
    countryCode: 'US',
    isActive: true,
    isVerified: true,
    deviceType: 'keypad',
    lastSynced: new Date(Date.now() - 3600000),
    otpCount: 5
  },
  {
    id: '3',
    userId: '2',
    number: '+44 20 7946 0958',
    label: 'UK Office',
    countryCode: 'UK',
    isActive: false,
    isVerified: true,
    deviceType: 'smartphone',
    otpCount: 0
  }
];

const mockOTPMessages: OTPMessage[] = [
  {
    id: '1',
    userId: '2',
    phoneNumberId: '1',
    phoneNumber: '+1 (555) 123-4567',
    code: '847291',
    sender: 'Amazon',
    message: 'Your Amazon verification code is 847291. Do not share it with anyone.',
    receivedAt: new Date(Date.now() - 300000),
    expiresAt: new Date(Date.now() + 600000),
    isRead: false,
    isEncrypted: true
  },
  {
    id: '2',
    userId: '2',
    phoneNumberId: '1',
    phoneNumber: '+1 (555) 123-4567',
    code: '529384',
    sender: 'Google',
    message: 'G-529384 is your Google verification code.',
    receivedAt: new Date(Date.now() - 900000),
    expiresAt: new Date(Date.now() + 600000),
    isRead: true,
    isEncrypted: true
  },
  {
    id: '3',
    userId: '2',
    phoneNumberId: '2',
    phoneNumber: '+1 (555) 987-6543',
    code: '718293',
    sender: 'Microsoft',
    message: 'Use code 718293 to verify your Microsoft account.',
    receivedAt: new Date(Date.now() - 1800000),
    expiresAt: new Date(Date.now() + 600000),
    isRead: false,
    isEncrypted: true
  }
];

const mockTickets: SupportTicket[] = [
  {
    id: '1',
    userId: '2',
    userName: 'John Doe',
    userEmail: 'john@example.com',
    subject: 'Cannot verify phone number',
    description: 'I am trying to add my work phone but the verification code is not coming through.',
    category: 'technical',
    priority: 'medium',
    status: 'open',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    responses: []
  },
  {
    id: '2',
    userId: '3',
    userName: 'Jane Smith',
    userEmail: 'jane@example.com',
    subject: 'Billing question about upgrade',
    description: 'I upgraded to Pro but was charged twice. Can you help refund the duplicate charge?',
    category: 'billing',
    priority: 'high',
    status: 'in-progress',
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    assignedTo: 'Admin User',
    responses: [
      {
        id: '1',
        ticketId: '2',
        userId: '1',
        userName: 'Admin User',
        userRole: 'admin',
        message: 'Hi Jane, I apologize for the inconvenience. I am looking into this issue and will process a refund for the duplicate charge within 24 hours.',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
      }
    ]
  },
  {
    id: '3',
    userId: '2',
    userName: 'John Doe',
    userEmail: 'john@example.com',
    subject: 'Feature request: Auto-forward OTPs',
    description: 'It would be great if I could auto-forward OTPs to my team members.',
    category: 'feature',
    priority: 'low',
    status: 'resolved',
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
    resolvedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
    responses: [
      {
        id: '2',
        ticketId: '3',
        userId: '1',
        userName: 'Admin User',
        userRole: 'admin',
        message: 'Thanks for the suggestion! We have added this to our roadmap and expect to release it in Q2.',
        createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000)
      }
    ]
  }
];

const mockPayments: Payment[] = [
  {
    id: '1',
    userId: '2',
    userName: 'John Doe',
    userEmail: 'john@example.com',
    amount: 19,
    currency: 'USD',
    planId: 'pro',
    billingCycle: 'monthly',
    status: 'completed',
    paymentMethod: 'card',
    transactionId: 'txn_1234567890',
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    paidAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  },
  {
    id: '2',
    userId: '3',
    userName: 'Jane Smith',
    userEmail: 'jane@example.com',
    amount: 9,
    currency: 'USD',
    planId: 'basic',
    billingCycle: 'monthly',
    status: 'completed',
    paymentMethod: 'paypal',
    transactionId: 'txn_0987654321',
    createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000),
    paidAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000)
  }
];

const mockHelpCategories: HelpCategory[] = [
  {
    id: '1',
    name: 'Getting Started',
    description: 'Learn the basics of using OTP Hub',
    icon: 'Rocket',
    articleCount: 5
  },
  {
    id: '2',
    name: 'Account & Billing',
    description: 'Manage your account and subscriptions',
    icon: 'CreditCard',
    articleCount: 8
  },
  {
    id: '3',
    name: 'Security',
    description: 'Learn about encryption and security features',
    icon: 'Shield',
    articleCount: 6
  },
  {
    id: '4',
    name: 'Troubleshooting',
    description: 'Common issues and solutions',
    icon: 'Wrench',
    articleCount: 10
  }
];

const mockHelpArticles: HelpArticle[] = [
  {
    id: '1',
    title: 'How to add your first phone number',
    content: 'Adding a phone number to OTP Hub is simple. Go to the Phone Numbers section...',
    category: 'Getting Started',
    tags: ['phone', 'setup', 'beginner'],
    views: 1250,
    helpful: 98,
    createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  },
  {
    id: '2',
    title: 'Understanding end-to-end encryption',
    content: 'OTPHub uses AES-256 encryption to secure your messages...',
    category: 'Security',
    tags: ['encryption', 'security', 'privacy'],
    views: 890,
    helpful: 95,
    createdAt: new Date(Date.now() - 80 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000)
  }
];

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [phoneNumbers, setPhoneNumbers] = useState<PhoneNumber[]>(mockPhoneNumbers);
  const [otpMessages, setOtpMessages] = useState<OTPMessage[]>(mockOTPMessages);
  const [tickets, setTickets] = useState<SupportTicket[]>(mockTickets);
  const [payments, setPayments] = useState<Payment[]>(mockPayments);
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [subscriptionPlans, setSubscriptionPlans] = useState<SubscriptionPlan[]>(mockSubscriptionPlans);
  const [adminSettings, setAdminSettings] = useState<AdminSettings>(defaultAdminSettings);
  const [helpArticles] = useState<HelpArticle[]>(mockHelpArticles);
  const [helpCategories] = useState<HelpCategory[]>(mockHelpCategories);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('otpHubUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
    setIsLoading(false);
  }, []);

  // Simulate real-time OTP updates
  useEffect(() => {
    if (!isAuthenticated) return;

    const interval = setInterval(() => {
      if (Math.random() < 0.1) {
        const senders = ['Amazon', 'Google', 'Microsoft', 'Apple', 'Netflix', 'PayPal', 'Stripe', 'GitHub'];
        const randomSender = senders[Math.floor(Math.random() * senders.length)];
        const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
        const activeNumbers = phoneNumbers.filter(p => p.isActive);
        
        if (activeNumbers.length > 0) {
          const randomNumber = activeNumbers[Math.floor(Math.random() * activeNumbers.length)];
          
          const newOTP: OTPMessage = {
            id: Date.now().toString(),
            userId: user?.id || '2',
            phoneNumberId: randomNumber.id,
            phoneNumber: randomNumber.number,
            code: randomCode,
            sender: randomSender,
            message: `Your ${randomSender} verification code is ${randomCode}. Do not share it with anyone.`,
            receivedAt: new Date(),
            expiresAt: new Date(Date.now() + 600000),
            isRead: false,
            isEncrypted: true
          };
          
          setOtpMessages(prev => [newOTP, ...prev]);
          toast.info(`New OTP from ${randomSender}`, {
            description: `Code: ${randomCode}`,
          });
        }
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [isAuthenticated, phoneNumbers, user]);

  const handleLogin = (email: string, _password: string) => {
    const foundUser = users.find(u => u.email === email);
    if (foundUser) {
      setUser(foundUser);
      setIsAuthenticated(true);
      localStorage.setItem('otpHubUser', JSON.stringify(foundUser));
      toast.success('Welcome back!');
    } else {
      // Create new user for demo
      const newUser: User = {
        id: Date.now().toString(),
        email,
        name: email.split('@')[0],
        role: 'user',
        subscription: 'free',
        createdAt: new Date(),
        isActive: true,
        phoneNumbersCount: 0,
        totalOTPs: 0
      };
      setUsers(prev => [...prev, newUser]);
      setUser(newUser);
      setIsAuthenticated(true);
      localStorage.setItem('otpHubUser', JSON.stringify(newUser));
      toast.success('Welcome!');
    }
  };

  const handleRegister = (name: string, email: string, _password: string) => {
    const newUser: User = {
      id: Date.now().toString(),
      email,
      name,
      role: 'user',
      subscription: 'free',
      createdAt: new Date(),
      isActive: true,
      phoneNumbersCount: 0,
      totalOTPs: 0
    };
    setUsers(prev => [...prev, newUser]);
    setUser(newUser);
    setIsAuthenticated(true);
    localStorage.setItem('otpHubUser', JSON.stringify(newUser));
    toast.success('Account created successfully!');
  };

  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('otpHubUser');
    toast.success('Logged out successfully');
  };

  const handleAddPhoneNumber = (number: string, label: string, deviceType: 'keypad' | 'smartphone') => {
    const newPhone: PhoneNumber = {
      id: Date.now().toString(),
      userId: user?.id || '2',
      number,
      label,
      countryCode: 'US',
      isActive: true,
      isVerified: false,
      deviceType,
      otpCount: 0
    };
    setPhoneNumbers(prev => [...prev, newPhone]);
    toast.success('Phone number added successfully');
  };

  const handleDeletePhoneNumber = (id: string) => {
    setPhoneNumbers(prev => prev.filter(p => p.id !== id));
    setOtpMessages(prev => prev.filter(o => o.phoneNumberId !== id));
    toast.success('Phone number removed');
  };

  const handleTogglePhoneStatus = (id: string) => {
    setPhoneNumbers(prev => prev.map(p => 
      p.id === id ? { ...p, isActive: !p.isActive } : p
    ));
  };

  const handleMarkAsRead = (otpId: string) => {
    setOtpMessages(prev => prev.map(o => 
      o.id === otpId ? { ...o, isRead: true } : o
    ));
  };

  const handleDeleteOTP = (otpId: string) => {
    setOtpMessages(prev => prev.filter(o => o.id !== otpId));
    toast.success('OTP deleted');
  };

  const handleUpgradeSubscription = (tier: string) => {
    if (user) {
      const updatedUser = { ...user, subscription: tier as any };
      setUser(updatedUser);
      setUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));
      localStorage.setItem('otpHubUser', JSON.stringify(updatedUser));
      toast.success(`Upgraded to ${tier} plan!`);
    }
  };

  // Ticket handlers
  const handleCreateTicket = (subject: string, description: string, category: SupportTicket['category'], priority: SupportTicket['priority']) => {
    if (!user) return;
    
    const newTicket: SupportTicket = {
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      subject,
      description,
      category,
      priority,
      status: 'open',
      createdAt: new Date(),
      updatedAt: new Date(),
      responses: []
    };
    setTickets(prev => [newTicket, ...prev]);
    toast.success('Ticket created successfully');
  };

  const handleAddTicketResponse = (ticketId: string, message: string) => {
    if (!user) return;
    
    const response: TicketResponse = {
      id: Date.now().toString(),
      ticketId,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      message,
      createdAt: new Date()
    };
    
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          responses: [...t.responses, response],
          updatedAt: new Date(),
          status: user.role === 'admin' ? 'in-progress' : t.status
        };
      }
      return t;
    }));
    toast.success('Response added');
  };

  const handleUpdateTicketStatus = (ticketId: string, status: SupportTicket['status']) => {
    setTickets(prev => prev.map(t => 
      t.id === ticketId ? { 
        ...t, 
        status, 
        updatedAt: new Date(),
        resolvedAt: status === 'resolved' ? new Date() : t.resolvedAt
      } : t
    ));
    toast.success(`Ticket ${status}`);
  };

  const handleAssignTicket = (ticketId: string, adminName: string) => {
    setTickets(prev => prev.map(t => 
      t.id === ticketId ? { ...t, assignedTo: adminName, updatedAt: new Date() } : t
    ));
    toast.success('Ticket assigned');
  };

  // Admin handlers
  const handleUpdateUser = (userId: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
    if (user?.id === userId) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem('otpHubUser', JSON.stringify(updatedUser));
    }
    toast.success('User updated');
  };

  const handleDeleteUser = (userId: string) => {
    setUsers(prev => prev.filter(u => u.id !== userId));
    toast.success('User deleted');
  };

  const handleUpdateSubscriptionPlan = (planId: string, updates: Partial<SubscriptionPlan>) => {
    setSubscriptionPlans(prev => prev.map(p => p.id === planId ? { ...p, ...updates } : p));
    toast.success('Plan updated');
  };

  const handleUpdateAdminSettings = (updates: Partial<AdminSettings>) => {
    setAdminSettings(prev => ({ ...prev, ...updates }));
    toast.success('Settings saved');
  };

  // Payment handler
  const handleProcessPayment = (planId: SubscriptionTier, billingCycle: 'monthly' | 'yearly', paymentMethod: Payment['paymentMethod']) => {
    if (!user) return;
    
    const plan = subscriptionPlans.find(p => p.id === planId);
    if (!plan) return;

    const amount = billingCycle === 'yearly' ? plan.price.yearly : plan.price.monthly;
    
    const newPayment: Payment = {
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      amount,
      currency: 'USD',
      planId,
      billingCycle,
      status: 'completed',
      paymentMethod,
      transactionId: `txn_${Date.now()}`,
      createdAt: new Date(),
      paidAt: new Date()
    };
    
    setPayments(prev => [newPayment, ...prev]);
    
    // Update user subscription
    const expiryDate = new Date();
    if (billingCycle === 'yearly') {
      expiryDate.setFullYear(expiryDate.getFullYear() + 1);
    } else {
      expiryDate.setMonth(expiryDate.getMonth() + 1);
    }
    
    handleUpgradeSubscription(planId);
    
    if (user) {
      const updatedUser = { ...user, subscriptionExpiry: expiryDate };
      setUser(updatedUser);
      setUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));
      localStorage.setItem('otpHubUser', JSON.stringify(updatedUser));
    }
    
    toast.success('Payment successful!');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#070c15] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#2467ec]"></div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Toaster 
        position="top-right" 
        toastOptions={{
          style: {
            background: '#0a1220',
            border: '1px solid #1a2744',
            color: '#fff',
          },
        }}
      />
      <Routes>
        <Route 
          path="/" 
          element={
            isAuthenticated ? 
              <Navigate to={user?.role === 'admin' ? '/admin' : '/dashboard'} /> : 
              <LandingPage subscriptionPlans={subscriptionPlans} adminSettings={adminSettings} />
          } 
        />
        <Route 
          path="/auth" 
          element={
            isAuthenticated ? 
              <Navigate to={user?.role === 'admin' ? '/admin' : '/dashboard'} /> : 
              <AuthPage onLogin={handleLogin} onRegister={handleRegister} adminSettings={adminSettings} />
          } 
        />
        <Route 
          path="/dashboard/*" 
          element={
            isAuthenticated && user?.role === 'user' ? (
              <Dashboard 
                user={user!}
                phoneNumbers={phoneNumbers.filter(p => p.userId === user?.id)}
                otpMessages={otpMessages.filter(o => o.userId === user?.id)}
                subscriptionPlans={subscriptionPlans}
                tickets={tickets.filter(t => t.userId === user?.id)}
                onLogout={handleLogout}
                onAddPhoneNumber={handleAddPhoneNumber}
                onDeletePhoneNumber={handleDeletePhoneNumber}
                onTogglePhoneStatus={handleTogglePhoneStatus}
                onMarkAsRead={handleMarkAsRead}
                onDeleteOTP={handleDeleteOTP}
                onUpgradeSubscription={handleUpgradeSubscription}
                onProcessPayment={handleProcessPayment}
                onCreateTicket={handleCreateTicket}
                onAddTicketResponse={handleAddTicketResponse}
              />
            ) : (
              <Navigate to="/auth" />
            )
          } 
        />
        <Route 
          path="/admin/*" 
          element={
            isAuthenticated && (user?.role === 'admin' || user?.role === 'superadmin') ? (
              <AdminPanel 
                user={user!}
                users={users}
                subscriptionPlans={subscriptionPlans}
                tickets={tickets}
                payments={payments}
                adminSettings={adminSettings}
                helpArticles={helpArticles}
                helpCategories={helpCategories}
                onLogout={handleLogout}
                onUpdateUser={handleUpdateUser}
                onDeleteUser={handleDeleteUser}
                onUpdateSubscriptionPlan={handleUpdateSubscriptionPlan}
                onUpdateAdminSettings={handleUpdateAdminSettings}
                onAddTicketResponse={handleAddTicketResponse}
                onUpdateTicketStatus={handleUpdateTicketStatus}
                onAssignTicket={handleAssignTicket}
              />
            ) : (
              <Navigate to="/auth" />
            )
          } 
        />
        <Route 
          path="/help" 
          element={
            <HelpCenter 
              helpArticles={helpArticles}
              helpCategories={helpCategories}
              isAuthenticated={isAuthenticated}
              user={user}
            />
          } 
        />
        <Route 
          path="/tickets" 
          element={
            isAuthenticated ? (
              <TicketsPage 
                user={user!}
                tickets={tickets.filter(t => t.userId === user?.id)}
                onCreateTicket={handleCreateTicket}
                onAddTicketResponse={handleAddTicketResponse}
              />
            ) : (
              <Navigate to="/auth" />
            )
          } 
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
