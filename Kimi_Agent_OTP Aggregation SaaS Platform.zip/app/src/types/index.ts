export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'user' | 'admin' | 'superadmin';
  subscription: SubscriptionTier;
  subscriptionExpiry?: Date;
  createdAt: Date;
  lastLogin?: Date;
  isActive: boolean;
  phoneNumbersCount: number;
  totalOTPs: number;
}

export type SubscriptionTier = 'free' | 'basic' | 'pro' | 'enterprise';

export interface PhoneNumber {
  id: string;
  userId: string;
  number: string;
  label: string;
  countryCode: string;
  isActive: boolean;
  isVerified: boolean;
  deviceType: 'keypad' | 'smartphone';
  lastSynced?: Date;
  otpCount: number;
}

export interface OTPMessage {
  id: string;
  userId: string;
  phoneNumberId: string;
  phoneNumber: string;
  code: string;
  sender: string;
  message: string;
  receivedAt: Date;
  expiresAt: Date;
  isRead: boolean;
  isEncrypted: boolean;
}

export interface SubscriptionPlan {
  id: SubscriptionTier;
  name: string;
  price: {
    monthly: number;
    yearly: number;
  };
  description: string;
  features: string[];
  limits: {
    phoneNumbers: number;
    otpPerMonth: number;
    storageDays: number;
  };
  isPopular?: boolean;
  isActive: boolean;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  subject: string;
  description: string;
  category: 'technical' | 'billing' | 'account' | 'feature' | 'other';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in-progress' | 'resolved' | 'closed';
  createdAt: Date;
  updatedAt: Date;
  resolvedAt?: Date;
  assignedTo?: string;
  responses: TicketResponse[];
}

export interface TicketResponse {
  id: string;
  ticketId: string;
  userId: string;
  userName: string;
  userRole: 'user' | 'admin' | 'superadmin';
  message: string;
  createdAt: Date;
}

export interface Payment {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  amount: number;
  currency: string;
  planId: SubscriptionTier;
  billingCycle: 'monthly' | 'yearly';
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  paymentMethod: 'card' | 'paypal' | 'crypto';
  transactionId?: string;
  createdAt: Date;
  paidAt?: Date;
}

export interface AdminSettings {
  siteName: string;
  siteDescription: string;
  logoUrl?: string;
  faviconUrl?: string;
  primaryColor: string;
  accentColor: string;
  enableRegistration: boolean;
  enableSocialLogin: boolean;
  maintenanceMode: boolean;
  supportEmail: string;
  maxPhoneNumbersFree: number;
  maxPhoneNumbersBasic: number;
  maxPhoneNumbersPro: number;
  maxPhoneNumbersEnterprise: number;
}

export interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  newUsersToday: number;
  totalOTPs: number;
  otpsToday: number;
  totalRevenue: number;
  revenueThisMonth: number;
  activeSubscriptions: number;
  pendingTickets: number;
  resolvedTicketsToday: number;
}

export interface SecuritySettings {
  twoFactorEnabled: boolean;
  encryptionKey?: string;
  lastPasswordChange?: Date;
  loginNotifications: boolean;
  trustedDevices: TrustedDevice[];
}

export interface TrustedDevice {
  id: string;
  name: string;
  lastLogin: Date;
  location: string;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  createdAt: Date;
  isRead: boolean;
}

export interface HelpArticle {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  views: number;
  helpful: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface HelpCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  articleCount: number;
}
